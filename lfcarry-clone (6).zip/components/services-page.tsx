"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Star, Clock, Shield, Search } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Link from "next/link"

// Datos de servicios (mantengo los mismos datos)
const services = [
  // Raid Carries
  {
    id: "last-wish",
    title: "Last Wish Raid",
    description: "Complete the Last Wish raid and get 1000 Voices exotic",
    price: 29,
    image: "/placeholder.svg?height=200&width=300&text=Last+Wish",
    features: ["1000 Voices Chance", "All Raid Loot", "Experienced Team", "Fast Completion"],
    rating: 4.9,
    completionTime: "1-2 hours",
    category: "Raids",
    difficulty: "High",
    serviceCategory: "raid-carries",
  },
  {
    id: "garden-salvation",
    title: "Garden of Salvation",
    description: "Complete Garden of Salvation and get Divinity exotic",
    price: 35,
    image: "/placeholder.svg?height=200&width=300&text=Garden+Salvation",
    features: ["Divinity Quest", "All Raid Loot", "Puzzle Solutions", "Professional Team"],
    rating: 4.8,
    completionTime: "2-3 hours",
    category: "Raids",
    difficulty: "Very High",
    serviceCategory: "raid-carries",
  },
  {
    id: "deep-stone-crypt",
    title: "Deep Stone Crypt",
    description: "Complete Deep Stone Crypt and get Eyes of Tomorrow",
    price: 32,
    image: "/placeholder.svg?height=200&width=300&text=Deep+Stone+Crypt",
    features: ["Eyes of Tomorrow", "Raid Weapons", "Armor Sets", "Fast Clear"],
    rating: 4.9,
    completionTime: "1.5-2 hours",
    category: "Raids",
    difficulty: "High",
    serviceCategory: "raid-carries",
  },
  {
    id: "vault-glass",
    title: "Vault of Glass",
    description: "Complete Vault of Glass and get Vex Mythoclast",
    price: 28,
    image: "/placeholder.svg?height=200&width=300&text=Vault+Glass",
    features: ["Vex Mythoclast", "Timelost Weapons", "Raid Armor", "Catalyst Chance"],
    rating: 4.8,
    completionTime: "1-2 hours",
    category: "Raids",
    difficulty: "Medium",
    serviceCategory: "raid-carries",
  },
  {
    id: "vow-disciple",
    title: "Vow of the Disciple",
    description: "Complete Vow of the Disciple and get Collective Obligation",
    price: 35,
    image: "/placeholder.svg?height=200&width=300&text=Vow+Disciple",
    features: ["Collective Obligation", "Red Border Weapons", "Raid Armor", "Triumph Progress"],
    rating: 4.7,
    completionTime: "2-3 hours",
    category: "Raids",
    difficulty: "Very High",
    serviceCategory: "raid-carries",
  },
  {
    id: "kings-fall",
    title: "King's Fall",
    description: "Complete King's Fall and get Touch of Malice",
    price: 33,
    image: "/placeholder.svg?height=200&width=300&text=Kings+Fall",
    features: ["Touch of Malice", "Harrowed Weapons", "Raid Armor", "Catalyst Progress"],
    rating: 4.8,
    completionTime: "2-3 hours",
    category: "Raids",
    difficulty: "High",
    serviceCategory: "raid-carries",
  },
  // Trials Services
  {
    id: "flawless-carry",
    title: "Trials Flawless (7-0)",
    description: "Get carried to flawless victory and lighthouse access",
    price: 79,
    image: "/placeholder.svg?height=200&width=300&text=Trials+Flawless",
    features: ["Flawless Guaranteed", "Adept Weapons", "Lighthouse Access", "Professional Players"],
    rating: 4.8,
    completionTime: "2-6 hours",
    category: "PvP",
    difficulty: "Very High",
    serviceCategory: "trials-flawless",
  },
  {
    id: "trials-wins",
    title: "Trials Wins",
    description: "Get specific number of wins in Trials",
    price: 15,
    image: "/placeholder.svg?height=200&width=300&text=Trials+Wins",
    features: ["Guaranteed Wins", "Trials Loot", "Fast Service", "Safe Account"],
    rating: 4.7,
    completionTime: "30min-2 hours",
    category: "PvP",
    difficulty: "High",
    serviceCategory: "trials-flawless",
  },
  {
    id: "trials-coaching",
    title: "Trials Coaching",
    description: "Learn from professionals while playing",
    price: 45,
    image: "/placeholder.svg?height=200&width=300&text=Trials+Coaching",
    features: ["Professional Coaching", "Skill Improvement", "Strategy Learning", "VOD Review"],
    rating: 4.9,
    completionTime: "2-3 hours",
    category: "PvP",
    difficulty: "Medium",
    serviceCategory: "trials-flawless",
  },
  // Dungeon Services
  {
    id: "duality",
    title: "Duality Dungeon",
    description: "Complete Duality dungeon and get exclusive rewards",
    price: 19,
    image: "/placeholder.svg?height=200&width=300&text=Duality",
    features: ["Heartshadow Exotic", "Dungeon Loot", "Triumph Progress", "Fast Completion"],
    rating: 4.9,
    completionTime: "45-90 min",
    category: "Dungeons",
    difficulty: "Medium",
    serviceCategory: "dungeon-carries",
  },
  {
    id: "grasp-avarice",
    title: "Grasp of Avarice",
    description: "Complete Grasp of Avarice and get Gjallarhorn catalyst",
    price: 17,
    image: "/placeholder.svg?height=200&width=300&text=Grasp+Avarice",
    features: ["Gjallarhorn Catalyst", "Dungeon Weapons", "Armor Sets", "Triumph Completion"],
    rating: 4.8,
    completionTime: "30-60 min",
    category: "Dungeons",
    difficulty: "Low",
    serviceCategory: "dungeon-carries",
  },
  {
    id: "prophecy",
    title: "Prophecy Dungeon",
    description: "Complete Prophecy dungeon for exclusive armor and weapons",
    price: 15,
    image: "/placeholder.svg?height=200&width=300&text=Prophecy",
    features: ["Unique Armor Set", "Dungeon Weapons", "Masterwork Materials", "Solo Flawless Option"],
    rating: 4.9,
    completionTime: "45-75 min",
    category: "Dungeons",
    difficulty: "Medium",
    serviceCategory: "dungeon-carries",
  },
  {
    id: "pit-heresy",
    title: "Pit of Heresy",
    description: "Complete Pit of Heresy and get Xenophage exotic",
    price: 14,
    image: "/placeholder.svg?height=200&width=300&text=Pit+Heresy",
    features: ["Xenophage Quest", "Dungeon Loot", "Masterwork Materials", "Fast Clear"],
    rating: 4.7,
    completionTime: "30-45 min",
    category: "Dungeons",
    difficulty: "Low",
    serviceCategory: "dungeon-carries",
  },
  {
    id: "shattered-throne",
    title: "Shattered Throne",
    description: "Complete Shattered Throne and get Wish-Ender",
    price: 16,
    image: "/placeholder.svg?height=200&width=300&text=Shattered+Throne",
    features: ["Wish-Ender Quest", "Dungeon Loot", "Triumph Progress", "Solo Flawless Option"],
    rating: 4.8,
    completionTime: "45-60 min",
    category: "Dungeons",
    difficulty: "Medium",
    serviceCategory: "dungeon-carries",
  },
  {
    id: "spire-watcher",
    title: "Spire of the Watcher",
    description: "Complete Spire of the Watcher dungeon",
    price: 20,
    image: "/placeholder.svg?height=200&width=300&text=Spire+Watcher",
    features: ["Hierarchy of Needs", "Dungeon Weapons", "Armor Sets", "Master Difficulty"],
    rating: 4.8,
    completionTime: "60-90 min",
    category: "Dungeons",
    difficulty: "High",
    serviceCategory: "dungeon-carries",
  },
  // Exotic Quests
  {
    id: "whirling-ovation",
    title: "Whirling Ovation Exotic Rocket Launcher",
    description: "Get the Whirling Ovation exotic rocket launcher",
    price: 89,
    image: "/placeholder.svg?height=200&width=300&text=Whirling+Ovation",
    features: ["Exotic Rocket Launcher", "Catalyst Available", "All Quest Steps", "Masterwork Option"],
    rating: 4.9,
    completionTime: "3-5 hours",
    category: "Exotic Quests",
    difficulty: "High",
    serviceCategory: "exotic-quests",
  },
  {
    id: "osteo-striga",
    title: "Osteo Striga Exotic SMG",
    description: "Get the Osteo Striga exotic submachine gun",
    price: 45,
    image: "/placeholder.svg?height=200&width=300&text=Osteo+Striga",
    features: ["Exotic SMG", "Catalyst Quest", "Poison Rounds", "Season Pass Progress"],
    rating: 4.8,
    completionTime: "2-3 hours",
    category: "Exotic Quests",
    difficulty: "Medium",
    serviceCategory: "exotic-quests",
  },
  {
    id: "parasite",
    title: "Parasite Exotic Grenade Launcher",
    description: "Complete the Parasite exotic quest",
    price: 55,
    image: "/placeholder.svg?height=200&width=300&text=Parasite",
    features: ["Exotic Grenade Launcher", "Worm God Powers", "Catalyst Available", "Quest Completion"],
    rating: 4.9,
    completionTime: "3-4 hours",
    category: "Exotic Quests",
    difficulty: "High",
    serviceCategory: "exotic-quests",
  },
  {
    id: "grand-overture",
    title: "Grand Overture Exotic Machine Gun",
    description: "Get the Grand Overture exotic machine gun",
    price: 65,
    image: "/placeholder.svg?height=200&width=300&text=Grand+Overture",
    features: ["Exotic Machine Gun", "Arc Damage", "Catalyst Quest", "High DPS Weapon"],
    rating: 4.7,
    completionTime: "4-6 hours",
    category: "Exotic Quests",
    difficulty: "High",
    serviceCategory: "exotic-quests",
  },
  {
    id: "dead-messenger",
    title: "Dead Messenger Exotic Grenade Launcher",
    description: "Complete the Dead Messenger exotic quest",
    price: 40,
    image: "/placeholder.svg?height=200&width=300&text=Dead+Messenger",
    features: ["Exotic Grenade Launcher", "Void Damage", "Catalyst Available", "PsiOps Progress"],
    rating: 4.8,
    completionTime: "2-3 hours",
    category: "Exotic Quests",
    difficulty: "Medium",
    serviceCategory: "exotic-quests",
  },
  // GM Nightfalls
  {
    id: "single-gm",
    title: "Single GM Nightfall",
    description: "Complete one Grandmaster Nightfall",
    price: 24,
    image: "/placeholder.svg?height=200&width=300&text=GM+Nightfall",
    features: ["Adept Weapons", "Ascendant Shards", "Platinum Rewards", "Safe Completion"],
    rating: 4.8,
    completionTime: "30-60 min",
    category: "GM Nightfalls",
    difficulty: "Very High",
    serviceCategory: "grandmaster-nightfalls",
  },
  {
    id: "conqueror-seal",
    title: "Conqueror Seal",
    description: "Complete all GM Nightfalls for Conqueror seal",
    price: 149,
    image: "/placeholder.svg?height=200&width=300&text=Conqueror+Seal",
    features: ["Conqueror Title", "All GM Completions", "Gilded Option", "Adept Weapon Collection"],
    rating: 4.9,
    completionTime: "1-2 weeks",
    category: "GM Nightfalls",
    difficulty: "Very High",
    serviceCategory: "grandmaster-nightfalls",
  },
  {
    id: "weekly-gm-farm",
    title: "Weekly GM Farm",
    description: "Farm the weekly GM Nightfall multiple times",
    price: 39,
    image: "/placeholder.svg?height=200&width=300&text=GM+Farm",
    features: ["Multiple Completions", "Adept Weapon Farming", "Material Farming", "Efficient Runs"],
    rating: 4.7,
    completionTime: "3-5 hours",
    category: "GM Nightfalls",
    difficulty: "Very High",
    serviceCategory: "grandmaster-nightfalls",
  },
  // Power Leveling
  {
    id: "soft-cap",
    title: "Soft Cap Leveling (1800)",
    description: "Level up to the soft cap quickly",
    price: 39,
    image: "/placeholder.svg?height=200&width=300&text=Soft+Cap",
    features: ["Fast Leveling", "Efficient Routes", "All Activities", "Gear Optimization"],
    rating: 4.7,
    completionTime: "1-2 days",
    category: "Power Leveling",
    difficulty: "Low",
    serviceCategory: "power-leveling",
  },
  {
    id: "hard-cap",
    title: "Hard Cap Leveling (1810)",
    description: "Level up to the hard cap",
    price: 69,
    image: "/placeholder.svg?height=200&width=300&text=Hard+Cap",
    features: ["Powerful Rewards", "Prime Engrams", "Weekly Activities", "High-Stat Armor"],
    rating: 4.8,
    completionTime: "3-5 days",
    category: "Power Leveling",
    difficulty: "Medium",
    serviceCategory: "power-leveling",
  },
  {
    id: "pinnacle-cap",
    title: "Pinnacle Cap (1820)",
    description: "Reach maximum power level",
    price: 99,
    image: "/placeholder.svg?height=200&width=300&text=Pinnacle+Cap",
    features: ["Pinnacle Activities", "Maximum Power", "God Roll Hunting", "Endgame Ready"],
    rating: 4.9,
    completionTime: "1-2 weeks",
    category: "Power Leveling",
    difficulty: "High",
    serviceCategory: "power-leveling",
  },
]

const categories = ["All", "Raids", "PvP", "Dungeons", "Exotic Quests", "GM Nightfalls", "Power Leveling"]

export function ServicesPage() {
  const searchParams = useSearchParams()
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const { addItem } = useCart()
  const [addingToCart, setAddingToCart] = useState<string | null>(null)

  // Obtener parámetro de búsqueda de la URL
  useEffect(() => {
    const urlSearch = searchParams.get("search")
    if (urlSearch) {
      setSearchQuery(urlSearch)
    }
  }, [searchParams])

  const filteredServices = services.filter((service) => {
    const matchesCategory = selectedCategory === "All" || service.category === selectedCategory
    const matchesSearch =
      searchQuery === "" ||
      service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.features.some((feature) => feature.toLowerCase().includes(searchQuery.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  const resultCount = filteredServices.length

  const handleAddToCart = async (service: (typeof services)[0]) => {
    setAddingToCart(service.id)

    addItem({
      id: service.id,
      name: service.title,
      price: service.price,
      quantity: 1,
      image: service.image,
    })

    setTimeout(() => {
      setAddingToCart(null)
    }, 500)
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />

      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Our Services</h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Professional Destiny 2 boosting services with guaranteed results and 24/7 support
            </p>
          </div>

          {searchQuery && (
            <div className="text-center mb-4">
              <p className="text-gray-400">
                Found {resultCount} service{resultCount !== 1 ? "s" : ""} matching "{searchQuery}"
              </p>
            </div>
          )}

          {/* Search and Filters */}
          <div className="mb-8 space-y-4">
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
            </div>

            <div className="flex flex-wrap justify-center gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category
                      ? "bg-blue-600 hover:bg-blue-700"
                      : "border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredServices.map((service) => (
              <Card
                key={service.id}
                className="bg-gray-800 border-gray-700 overflow-hidden hover:shadow-lg hover:border-blue-500 transition-all duration-300"
              >
                <div className="relative">
                  <img
                    src={service.image || "/placeholder.svg"}
                    alt={service.title}
                    className="w-full h-48 object-cover"
                  />
                  <Badge className="absolute top-3 left-3 bg-blue-600 text-white">{service.category}</Badge>
                  <Badge
                    className={`absolute top-3 right-3 ${
                      service.difficulty === "Low"
                        ? "bg-green-600"
                        : service.difficulty === "Medium"
                          ? "bg-yellow-600"
                          : service.difficulty === "High"
                            ? "bg-orange-600"
                            : "bg-red-600"
                    } text-white`}
                  >
                    {service.difficulty}
                  </Badge>
                </div>

                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl font-bold text-white">{service.title}</CardTitle>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium text-gray-300">{service.rating}</span>
                    </div>
                  </div>
                  <CardDescription className="text-gray-400">{service.description}</CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{service.completionTime}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Shield className="w-4 h-4" />
                      <span>Safe & Secure</span>
                    </div>
                  </div>

                  <ul className="space-y-1">
                    {service.features.map((feature, index) => (
                      <li key={index} className="text-sm text-gray-300 flex items-center">
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-600">
                    <div className="text-2xl font-bold text-blue-400">${service.price}</div>
                    <div className="flex space-x-2">
                      {/* CAMBIO AQUÍ: Ahora va al servicio específico, no a la categoría */}
                      <Link href={`/service/${service.id}`}>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-gray-500 text-gray-300 hover:bg-gray-700 hover:text-white bg-transparent"
                        >
                          View Details
                        </Button>
                      </Link>
                      <Button
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700"
                        onClick={() => handleAddToCart(service)}
                        disabled={addingToCart === service.id}
                      >
                        {addingToCart === service.id ? "Adding..." : "Add to Cart"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredServices.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg mb-4">
                {searchQuery
                  ? `No services found matching "${searchQuery}" in ${selectedCategory === "All" ? "all categories" : selectedCategory}.`
                  : `No services found in ${selectedCategory}.`}
              </p>
              {(searchQuery || selectedCategory !== "All") && (
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery("")
                    setSelectedCategory("All")
                  }}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
                >
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
