import { Star } from "lucide-react"

export function TrustBadge() {
  return (
    <div className="flex items-center justify-center mb-8">
      <div className="bg-green-900/30 border border-green-700 rounded-lg px-6 py-3 flex items-center space-x-4">
        <span className="text-green-300 font-medium">Trusted by thousands</span>
        <div className="flex items-center space-x-1">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="h-4 w-4 fill-green-400 text-green-400" />
          ))}
        </div>
        <span className="text-green-300">
          Over <span className="font-semibold">10,300</span> reviews across all platforms
        </span>
        <div className="flex items-center space-x-1">
          <span className="text-green-300 font-semibold">REVIEWS</span>
          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
          <span className="text-green-300 text-sm">io</span>
        </div>
      </div>
    </div>
  )
}
