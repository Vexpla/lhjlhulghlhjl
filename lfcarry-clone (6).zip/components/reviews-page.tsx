"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, ThumbsUp, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

const reviews = [
  {
    id: 1,
    name: "Guardian_Alex",
    avatar: "/placeholder.svg?height=60&width=60",
    rating: 5,
    service: "Raid Carry - Last Wish",
    date: "2024-01-20",
    verified: true,
    helpful: 24,
    review:
      "Absolutely amazing service! The team was professional, patient, and got me through Last Wish flawlessly. Communication was excellent throughout the entire process. Highly recommend!",
  },
  {
    id: 2,
    name: "TrialsWarrior_Sarah",
    avatar: "/placeholder.svg?height=60&width=60",
    rating: 5,
    service: "Trials Flawless",
    date: "2024-01-18",
    verified: true,
    helpful: 31,
    review:
      "Went flawless for the first time ever! The carry team was incredibly skilled and made it look easy. Got my adept weapons and had a great experience. Will definitely use again!",
  },
  {
    id: 3,
    name: "PowerLevel_Mike",
    avatar: "/placeholder.svg?height=60&width=60",
    rating: 4,
    service: "Power Leveling",
    date: "2024-01-15",
    verified: true,
    helpful: 18,
    review:
      "Great power leveling service. Took me from 1750 to pinnacle cap in just 2 days. Only minor issue was communication could have been better, but results were exactly as promised.",
  },
  {
    id: 4,
    name: "DungeonMaster_Emma",
    avatar: "/placeholder.svg?height=60&width=60",
    rating: 5,
    service: "Dungeon Carry - Duality",
    date: "2024-01-12",
    verified: true,
    helpful: 27,
    review:
      "Perfect dungeon carry! Not only did they complete it quickly, but they also explained the mechanics so I could learn. Got the exotic I wanted and learned something new. Excellent!",
  },
  {
    id: 5,
    name: "NightfallHero_David",
    avatar: "/placeholder.svg?height=60&width=60",
    rating: 5,
    service: "GM Nightfall",
    date: "2024-01-10",
    verified: true,
    helpful: 22,
    review:
      "GM Nightfall completion was smooth and professional. Team knew all the strategies and we finished without any issues. Got my adept weapon with great rolls. Highly satisfied!",
  },
  {
    id: 6,
    name: "ExoticHunter_Lisa",
    avatar: "/placeholder.svg?height=60&width=60",
    rating: 5,
    service: "Exotic Quest - Divinity",
    date: "2024-01-08",
    verified: true,
    helpful: 19,
    review:
      "Finally got Divinity! The team was patient with the puzzle sections and made sure I understood each step. Great communication and professional service throughout.",
  },
]

const services = [
  "All Services",
  "Raid Carry",
  "Trials Flawless",
  "Dungeon Carry",
  "GM Nightfall",
  "Power Leveling",
  "Exotic Quest",
]
const ratings = ["All Ratings", "5 Stars", "4 Stars", "3 Stars", "2 Stars", "1 Star"]

export function ReviewsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedService, setSelectedService] = useState("All Services")
  const [selectedRating, setSelectedRating] = useState("All Ratings")

  const filteredReviews = reviews.filter((review) => {
    const matchesSearch =
      review.review.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.service.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesService =
      selectedService === "All Services" ||
      review.service.includes(selectedService.replace(" Carry", "").replace(" Flawless", ""))

    const matchesRating =
      selectedRating === "All Ratings" ||
      selectedRating === `${review.rating} Stars` ||
      selectedRating === `${review.rating} Star`

    return matchesSearch && matchesService && matchesRating
  })

  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
  const totalReviews = reviews.length

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />

      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Customer Reviews</h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              See what our customers say about our Destiny 2 boosting services
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="bg-gray-800 border-gray-700 text-center">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-blue-400 mb-2">{averageRating.toFixed(1)}</div>
                <div className="flex justify-center mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${i < Math.floor(averageRating) ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}`}
                    />
                  ))}
                </div>
                <div className="text-gray-300">Average Rating</div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 text-center">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-blue-400 mb-2">{totalReviews}</div>
                <div className="text-gray-300">Total Reviews</div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 text-center">
              <CardContent className="p-6">
                <div className="text-4xl font-bold text-blue-400 mb-2">98%</div>
                <div className="text-gray-300">Satisfaction Rate</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="mb-8 space-y-4">
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search reviews..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              <Select value={selectedService} onValueChange={setSelectedService}>
                <SelectTrigger className="w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Filter by service" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {services.map((service) => (
                    <SelectItem key={service} value={service} className="text-white hover:bg-gray-700">
                      {service}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedRating} onValueChange={setSelectedRating}>
                <SelectTrigger className="w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Filter by rating" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {ratings.map((rating) => (
                    <SelectItem key={rating} value={rating} className="text-white hover:bg-gray-700">
                      {rating}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Reviews */}
          <div className="space-y-6">
            {filteredReviews.map((review) => (
              <Card key={review.id} className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <Avatar className="h-12 w-12 border border-gray-600">
                      <AvatarImage src={review.avatar || "/placeholder.svg"} alt={review.name} />
                      <AvatarFallback className="bg-gray-700 text-white">{review.name.charAt(0)}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold text-white">{review.name}</h3>
                          {review.verified && (
                            <Badge className="bg-green-900/50 text-green-300 border-green-700">Verified Purchase</Badge>
                          )}
                        </div>
                        <div className="text-sm text-gray-400">{review.date}</div>
                      </div>

                      <div className="flex items-center space-x-2 mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}`}
                            />
                          ))}
                        </div>
                        <Badge className="bg-blue-900/50 text-blue-300 border-blue-700">{review.service}</Badge>
                      </div>

                      <p className="text-gray-300 mb-4">{review.review}</p>

                      <div className="flex items-center justify-between">
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-gray-700">
                          <ThumbsUp className="w-4 h-4 mr-1" />
                          Helpful ({review.helpful})
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredReviews.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No reviews found matching your criteria.</p>
            </div>
          )}

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <Card className="bg-gray-800 border-gray-700 max-w-2xl mx-auto">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-4">Ready to Experience Our Service?</h3>
                <p className="text-gray-300 mb-6">
                  Join thousands of satisfied customers and get your Destiny 2 goals completed today!
                </p>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">Browse Services</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
