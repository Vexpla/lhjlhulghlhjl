import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight, Search, CreditCard, UserCheck, Trophy } from "lucide-react"
import Link from "next/link"

export function HowItWorks() {
  const steps = [
    {
      icon: Search,
      title: "Choose Your Service",
      description: "Browse our Destiny 2 services and select the activity you need help with.",
    },
    {
      icon: CreditCard,
      title: "Place Your Order",
      description: "Customize your order with platform, difficulty, and service type preferences.",
    },
    {
      icon: UserCheck,
      title: "Get Matched",
      description: "We'll assign you a professional Destiny 2 player based on your requirements.",
    },
    {
      icon: Trophy,
      title: "Complete & Enjoy",
      description: "Track your order progress and enjoy your rewards once completed.",
    },
  ]

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">How It Works</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Our simple 4-step process gets you the Destiny 2 rewards you want quickly and safely
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {steps.map((step, index) => (
            <Card
              key={index}
              className="bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-orange-500/50 transition-all duration-300 relative"
            >
              <CardContent className="p-6 text-center">
                <div className="bg-orange-600/20 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                  <step.icon className="h-8 w-8 text-orange-400" />
                </div>
                <div className="bg-orange-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-lg font-bold absolute -top-3 -left-3">
                  {index + 1}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-gray-400">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-center">
          <Link href="/services">
            <Button className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-6 text-lg">
              Get Started Now
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
