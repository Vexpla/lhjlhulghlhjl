import { Card, CardContent } from "@/components/ui/card"
import { Shield, Lock, Clock, Zap, Award, HeartHandshake } from "lucide-react"

export function Guarantees() {
  const guarantees = [
    {
      icon: Shield,
      title: "Account Safety",
      description:
        "We use VPNs matching your location and maintain your normal play patterns to keep your account completely safe.",
    },
    {
      icon: Lock,
      title: "Privacy Protection",
      description: "Your personal information is encrypted and never shared. We respect your privacy completely.",
    },
    {
      icon: Clock,
      title: "On-Time Delivery",
      description: "We guarantee completion within the estimated timeframe or provide compensation for delays.",
    },
    {
      icon: Zap,
      title: "24/7 Support",
      description: "Our support team is available around the clock via live chat, Discord, or email.",
    },
    {
      icon: Award,
      title: "Completion Guarantee",
      description: "We guarantee to complete your service or continue working until it's done at no additional cost.",
    },
    {
      icon: HeartHandshake,
      title: "Money-Back Guarantee",
      description: "Not satisfied with our service? We offer a full refund within 24 hours of order completion.",
    },
  ]

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Guarantees</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We're committed to providing a safe, reliable, and high-quality Destiny 2 boosting service
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {guarantees.map((guarantee, index) => (
            <Card
              key={index}
              className="bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-orange-500/50 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="bg-orange-600/20 rounded-full p-4 w-16 h-16 mb-6 flex items-center justify-center">
                  <guarantee.icon className="h-8 w-8 text-orange-400" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{guarantee.title}</h3>
                <p className="text-gray-400">{guarantee.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
