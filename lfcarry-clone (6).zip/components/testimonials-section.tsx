import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star } from "lucide-react"

export function TestimonialsSection() {
  const testimonials = [
    {
      name: "Carlos M.",
      avatar: "/placeholder.svg?height=40&width=40",
      rating: 5,
      text: "Amazing service! I went from Gold to Platinum in just 2 days. The players are very professional and support is excellent.",
      game: "League of Legends",
    },
    {
      name: "Ana R.",
      avatar: "/placeholder.svg?height=40&width=40",
      rating: 5,
      text: "I used the duo queue service and not only did I rank up, but I also learned a lot. Totally recommended.",
      game: "Valorant",
    },
    {
      name: "Miguel S.",
      avatar: "/placeholder.svg?height=40&width=40",
      rating: 5,
      text: "Fast, safe and reliable. I've used LFCarry several times and they always deliver on their promises.",
      game: "CS2",
    },
    {
      name: "Laura P.",
      avatar: "/placeholder.svg?height=40&width=40",
      rating: 5,
      text: "The best boosting service I've tried. Fair prices and guaranteed results.",
      game: "League of Legends",
    },
    {
      name: "David L.",
      avatar: "/placeholder.svg?height=40&width=40",
      rating: 5,
      text: "Excellent communication throughout the process. I could see the progress in real time.",
      game: "Valorant",
    },
    {
      name: "Sofia G.",
      avatar: "/placeholder.svg?height=40&width=40",
      rating: 5,
      text: "Premium service at an affordable price. The players are truly professional.",
      game: "Overwatch 2",
    },
  ]

  return (
    <section id="testimonials" className="py-20 px-4 bg-black/20">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">What Our Customers Say</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Thousands of players trust us to achieve their goals
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Avatar className="h-12 w-12 mr-4">
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-purple-400 text-sm">{testimonial.game}</p>
                  </div>
                </div>

                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                <p className="text-gray-300 italic">"{testimonial.text}"</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
