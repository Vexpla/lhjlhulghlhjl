import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sword, Shield, Trophy, Zap, Crown, Target } from "lucide-react"
import Link from "next/link"

export function ServicesOverview() {
  const services = [
    {
      icon: Sword,
      title: "Raid Carries",
      description: "Complete any raid with our experienced team",
      features: ["All current raids", "Master difficulty available", "Guaranteed loot", "Fast completion"],
      price: "From $29.99",
      popular: true,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: Trophy,
      title: "Trials of Osiris",
      description: "Go flawless and earn exclusive rewards",
      features: ["Flawless runs", "Adept weapons", "Trials armor", "Lighthouse access"],
      price: "From $79.99",
      popular: true,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: Shield,
      title: "Dungeon Carries",
      description: "Master and Legend dungeon completions",
      features: ["All dungeons", "Master difficulty", "Exotic weapons", "Triumphs"],
      price: "From $19.99",
      popular: false,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: Zap,
      title: "GM Nightfalls",
      description: "Grandmaster Nightfall completions and Conqueror seal",
      features: ["All GM Nightfalls", "Conqueror seal", "Adept weapons", "High-stat armor"],
      price: "From $24.99",
      popular: false,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: Crown,
      title: "Seals & Titles",
      description: "Earn prestigious seals and titles",
      features: ["All available seals", "Title completion", "Triumph hunting", "Seasonal seals"],
      price: "From $99.99",
      popular: false,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: Target,
      title: "Power Leveling",
      description: "Reach maximum light level quickly",
      features: ["Soft cap leveling", "Hard cap leveling", "Pinnacle cap", "Artifact XP"],
      price: "From $39.99",
      popular: false,
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <section className="py-20 px-4 bg-[#0D1117]">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Destiny 2 Services</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Professional carries and boosting services for all Destiny 2 activities. Fast, safe, and guaranteed results.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className={`bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-orange-500/50 transition-all duration-300 overflow-hidden group ${
                service.popular ? "border-orange-500/50 shadow-lg shadow-orange-500/10" : ""
              }`}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image || "/placeholder.svg"}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {service.popular && (
                  <Badge className="absolute top-4 right-4 bg-orange-600 text-white font-medium">Most Popular</Badge>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                <div className="absolute bottom-4 left-4 flex items-center">
                  <div className="bg-orange-600/20 rounded-full p-2 w-10 h-10 flex items-center justify-center mr-3">
                    <service.icon className="h-5 w-5 text-orange-400" />
                  </div>
                  <h3 className="text-xl font-bold text-white">{service.title}</h3>
                </div>
              </div>
              <CardHeader className="pb-4">
                <CardDescription className="text-gray-400">{service.description}</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, i) => (
                    <li key={i} className="text-gray-300 text-sm flex items-center">
                      <div className="w-1.5 h-1.5 bg-orange-400 rounded-full mr-2"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-gray-400">Starting at</span>
                  <span className="text-xl font-bold text-white">{service.price}</span>
                </div>
                <Link href="/services">
                  <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white">View Details</Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/services">
            <Button
              variant="outline"
              className="border-orange-500 text-orange-400 hover:bg-orange-500/10 bg-transparent px-8 py-3"
            >
              View All Services
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
