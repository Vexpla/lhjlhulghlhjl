import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, Star } from "lucide-react"

export function PricingSection() {
  const plans = [
    {
      name: "Basic",
      price: "$15",
      description: "Perfect to get started",
      features: ["1-3 divisions", "Email support", "Basic progress", "Rank guarantee"],
      popular: false,
    },
    {
      name: "Pro",
      price: "$35",
      description: "Most popular among players",
      features: [
        "4-6 divisions",
        "24/7 support",
        "Real-time progress",
        "Rank guarantee",
        "Duo queue available",
        "Discount on future orders",
      ],
      popular: true,
    },
    {
      name: "Premium",
      price: "$65",
      description: "For serious players",
      features: [
        "7+ divisions",
        "Priority 24/7 support",
        "Real-time progress",
        "Rank guarantee",
        "Duo queue included",
        "Personal coaching",
        "Permanent discounts",
        "Access to pro players",
      ],
      popular: false,
    },
  ]

  return (
    <section id="pricing" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Transparent Pricing</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Choose the plan that best fits your needs. All include satisfaction guarantee.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 ${plan.popular ? "ring-2 ring-purple-500 transform scale-105" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-purple-600 text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center">
                    <Star className="w-4 h-4 mr-1" />
                    Most Popular
                  </div>
                </div>
              )}
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-white text-2xl">{plan.name}</CardTitle>
                <div className="text-4xl font-bold text-white mb-2">
                  {plan.price}
                  <span className="text-lg text-gray-400 font-normal">/division</span>
                </div>
                <CardDescription className="text-gray-300">{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-gray-300 flex items-center">
                      <Check className="w-5 h-5 text-purple-400 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${plan.popular ? "bg-purple-600 hover:bg-purple-700" : "bg-gray-700 hover:bg-gray-600"} text-white`}
                >
                  Choose Plan
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
