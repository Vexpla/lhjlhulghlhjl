"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { ChevronRight } from "lucide-react"

export function PriceCalculator() {
  const [selectedService, setSelectedService] = useState("")
  const [selectedDifficulty, setSelectedDifficulty] = useState("")
  const [platform, setPlatform] = useState("")
  const [serviceType, setServiceType] = useState("")
  const [isExpress, setIsExpress] = useState(false)
  const [isStreaming, setIsStreaming] = useState(false)
  const [isGuaranteed, setIsGuaranteed] = useState(false)

  // Price calculation logic
  const getBasePrice = () => {
    if (!selectedService || !selectedDifficulty) return 0

    const prices: { [key: string]: { [key: string]: number } } = {
      "raid-carry": {
        normal: 29.99,
        master: 49.99,
      },
      "trials-flawless": {
        flawless: 79.99,
        carry: 59.99,
      },
      "dungeon-carry": {
        normal: 19.99,
        master: 34.99,
      },
      "gm-nightfall": {
        completion: 24.99,
        conqueror: 149.99,
      },
      "power-leveling": {
        "soft-cap": 39.99,
        "hard-cap": 69.99,
        "pinnacle-cap": 99.99,
      },
      seals: {
        seasonal: 99.99,
        legacy: 149.99,
      },
    }

    return prices[selectedService]?.[selectedDifficulty] || 0
  }

  const basePrice = getBasePrice()
  const expressPrice = isExpress ? basePrice * 0.5 : 0
  const streamingPrice = isStreaming ? basePrice * 0.2 : 0
  const guaranteedPrice = isGuaranteed ? basePrice * 0.3 : 0
  const totalPrice = basePrice + expressPrice + streamingPrice + guaranteedPrice

  const getEstimatedTime = () => {
    if (!selectedService || !selectedDifficulty) return "Select service"

    const times: { [key: string]: { [key: string]: string } } = {
      "raid-carry": {
        normal: "1-2 hours",
        master: "2-4 hours",
      },
      "trials-flawless": {
        flawless: "2-6 hours",
        carry: "1-4 hours",
      },
      "dungeon-carry": {
        normal: "30-60 min",
        master: "1-2 hours",
      },
      "gm-nightfall": {
        completion: "30-45 min",
        conqueror: "1-2 weeks",
      },
      "power-leveling": {
        "soft-cap": "1-2 days",
        "hard-cap": "3-5 days",
        "pinnacle-cap": "1-2 weeks",
      },
      seals: {
        seasonal: "1-3 weeks",
        legacy: "2-4 weeks",
      },
    }

    const baseTime = times[selectedService]?.[selectedDifficulty] || "TBD"
    return isExpress ? `${baseTime} (Express)` : baseTime
  }

  return (
    <section id="price-calculator" className="py-20 px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] bg-cover opacity-5 z-0"></div>
      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Price Calculator</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Get an accurate price estimate for your Destiny 2 service with our interactive calculator
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-gray-800">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-white">Customize Your Order</CardTitle>
                <CardDescription className="text-gray-400">
                  Select your preferred service and options to get a personalized quote
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white mb-2 block">Service Type</Label>
                      <Select value={selectedService} onValueChange={setSelectedService}>
                        <SelectTrigger className="w-full bg-gray-800 border-gray-700 text-white">
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="raid-carry" className="text-white hover:bg-gray-700">
                            Raid Carry
                          </SelectItem>
                          <SelectItem value="trials-flawless" className="text-white hover:bg-gray-700">
                            Trials of Osiris
                          </SelectItem>
                          <SelectItem value="dungeon-carry" className="text-white hover:bg-gray-700">
                            Dungeon Carry
                          </SelectItem>
                          <SelectItem value="gm-nightfall" className="text-white hover:bg-gray-700">
                            GM Nightfall
                          </SelectItem>
                          <SelectItem value="power-leveling" className="text-white hover:bg-gray-700">
                            Power Leveling
                          </SelectItem>
                          <SelectItem value="seals" className="text-white hover:bg-gray-700">
                            Seals & Titles
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedService && (
                      <div>
                        <Label className="text-white mb-2 block">Difficulty/Type</Label>
                        <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                          <SelectTrigger className="w-full bg-gray-800 border-gray-700 text-white">
                            <SelectValue placeholder="Select difficulty" />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-700">
                            {selectedService === "raid-carry" && (
                              <>
                                <SelectItem value="normal" className="text-white hover:bg-gray-700">
                                  Normal Mode
                                </SelectItem>
                                <SelectItem value="master" className="text-white hover:bg-gray-700">
                                  Master Mode
                                </SelectItem>
                              </>
                            )}
                            {selectedService === "trials-flawless" && (
                              <>
                                <SelectItem value="flawless" className="text-white hover:bg-gray-700">
                                  Flawless (7-0)
                                </SelectItem>
                                <SelectItem value="carry" className="text-white hover:bg-gray-700">
                                  Trials Carry
                                </SelectItem>
                              </>
                            )}
                            {selectedService === "dungeon-carry" && (
                              <>
                                <SelectItem value="normal" className="text-white hover:bg-gray-700">
                                  Normal
                                </SelectItem>
                                <SelectItem value="master" className="text-white hover:bg-gray-700">
                                  Master
                                </SelectItem>
                              </>
                            )}
                            {selectedService === "gm-nightfall" && (
                              <>
                                <SelectItem value="completion" className="text-white hover:bg-gray-700">
                                  Single Completion
                                </SelectItem>
                                <SelectItem value="conqueror" className="text-white hover:bg-gray-700">
                                  Conqueror Seal
                                </SelectItem>
                              </>
                            )}
                            {selectedService === "power-leveling" && (
                              <>
                                <SelectItem value="soft-cap" className="text-white hover:bg-gray-700">
                                  To Soft Cap (1800)
                                </SelectItem>
                                <SelectItem value="hard-cap" className="text-white hover:bg-gray-700">
                                  To Hard Cap (1810)
                                </SelectItem>
                                <SelectItem value="pinnacle-cap" className="text-white hover:bg-gray-700">
                                  To Pinnacle Cap (1820)
                                </SelectItem>
                              </>
                            )}
                            {selectedService === "seals" && (
                              <>
                                <SelectItem value="seasonal" className="text-white hover:bg-gray-700">
                                  Seasonal Seal
                                </SelectItem>
                                <SelectItem value="legacy" className="text-white hover:bg-gray-700">
                                  Legacy Seal
                                </SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <div>
                      <Label className="text-white mb-2 block">Platform</Label>
                      <Select value={platform} onValueChange={setPlatform}>
                        <SelectTrigger className="w-full bg-gray-800 border-gray-700 text-white">
                          <SelectValue placeholder="Select platform" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="pc" className="text-white hover:bg-gray-700">
                            PC (Steam/Epic)
                          </SelectItem>
                          <SelectItem value="xbox" className="text-white hover:bg-gray-700">
                            Xbox
                          </SelectItem>
                          <SelectItem value="playstation" className="text-white hover:bg-gray-700">
                            PlayStation
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label className="text-white mb-2 block">Service Method</Label>
                      <Select value={serviceType} onValueChange={setServiceType}>
                        <SelectTrigger className="w-full bg-gray-800 border-gray-700 text-white">
                          <SelectValue placeholder="Select method" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-700">
                          <SelectItem value="recovery" className="text-white hover:bg-gray-700">
                            Account Recovery
                          </SelectItem>
                          <SelectItem value="sherpa" className="text-white hover:bg-gray-700">
                            Sherpa (Play with us)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-4 pt-4">
                      <h4 className="text-white font-medium">Additional Options</h4>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="express" className="text-gray-300">
                            Express Service (+50%)
                          </Label>
                          <Switch id="express" checked={isExpress} onCheckedChange={setIsExpress} />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="streaming" className="text-gray-300">
                            Stream Service (+20%)
                          </Label>
                          <Switch id="streaming" checked={isStreaming} onCheckedChange={setIsStreaming} />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="guaranteed" className="text-gray-300">
                            Guaranteed Completion (+30%)
                          </Label>
                          <Switch id="guaranteed" checked={isGuaranteed} onCheckedChange={setIsGuaranteed} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="bg-gradient-to-br from-gray-900 to-gray-950 border-gray-800 sticky top-24">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-white">Order Summary</CardTitle>
                <CardDescription className="text-gray-400">Review your order details and price</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {basePrice > 0 ? (
                  <>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Base Price:</span>
                        <span className="text-white">${basePrice.toFixed(2)}</span>
                      </div>
                      {isExpress && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Express Service:</span>
                          <span className="text-white">+${expressPrice.toFixed(2)}</span>
                        </div>
                      )}
                      {isStreaming && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Stream Service:</span>
                          <span className="text-white">+${streamingPrice.toFixed(2)}</span>
                        </div>
                      )}
                      {isGuaranteed && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Guaranteed Completion:</span>
                          <span className="text-white">+${guaranteedPrice.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="pt-3 border-t border-gray-800 flex justify-between">
                        <span className="text-lg font-medium text-white">Total Price:</span>
                        <span className="text-lg font-bold text-orange-400">${totalPrice.toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Estimated Time:</span>
                        <span className="text-white">{getEstimatedTime()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Service Method:</span>
                        <span className="text-white">{serviceType || "Not selected"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Platform:</span>
                        <span className="text-white">{platform || "Not selected"}</span>
                      </div>
                    </div>

                    <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-6">
                      Proceed to Checkout
                      <ChevronRight className="ml-2 h-5 w-5" />
                    </Button>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400 mb-4">Select a service and difficulty to see pricing</p>
                    <Button disabled className="w-full bg-gray-700 text-gray-400 py-6 cursor-not-allowed">
                      Select Service First
                    </Button>
                  </div>
                )}

                <div className="text-center text-sm text-gray-400">
                  By placing an order, you agree to our{" "}
                  <a href="/terms" className="text-orange-400 hover:underline">
                    Terms of Service
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
