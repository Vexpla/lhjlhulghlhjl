"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function CookieBanner() {
  const [showBanner, setShowBanner] = useState(false)

  useEffect(() => {
    const hasAcceptedCookies = localStorage.getItem("cookies-accepted")
    if (!hasAcceptedCookies) {
      setShowBanner(true)
    }
  }, [])

  const acceptAllCookies = () => {
    localStorage.setItem("cookies-accepted", "true")
    setShowBanner(false)
  }

  const rejectAllCookies = () => {
    localStorage.setItem("cookies-accepted", "false")
    setShowBanner(false)
  }

  if (!showBanner) return null

  return (
    <div className="fixed top-4 right-4 z-50 max-w-sm">
      <div className="bg-gray-800 text-white p-4 rounded-lg shadow-lg border border-gray-700">
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-semibold text-sm">Cookie Consent</h3>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-gray-700 h-6 w-6"
            onClick={rejectAllCookies}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-sm text-gray-300 mb-4">
          This website requires cookies to function properly. Please enable cookies to continue.
        </p>
        <div className="space-y-2">
          <Button onClick={acceptAllCookies} className="w-full bg-pink-600 hover:bg-pink-700 text-white text-sm py-2">
            ACCEPT ALL COOKIES
          </Button>
          <Button
            onClick={rejectAllCookies}
            variant="outline"
            className="w-full border-gray-600 text-gray-300 hover:bg-gray-700 text-sm py-2 bg-transparent"
          >
            Reject All Cookies
          </Button>
        </div>
      </div>
    </div>
  )
}
