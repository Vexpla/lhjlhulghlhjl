"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, Clock, Shield, CheckCircle, ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"
import { useCart } from "@/hooks/use-cart"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

// Expanded services data based on lfcarry.com/d2
const servicesData = {
  "raid-carries": {
    title: "Raid Carries",
    description: "Complete any raid with our professional team",
    basePrice: 25,
    image: "/placeholder.svg?height=400&width=600&text=Raid+Carries",
    rating: 4.9,
    completionTime: "1-3 hours",
    category: "PvE",
    services: [
      {
        id: "last-wish",
        name: "Last Wish Raid",
        description: "Complete the Last Wish raid and get 1000 Voices exotic",
        basePrice: 29,
        completionTime: "1-2 hours",
        options: [
          { id: "1000-voices", name: "1000 Voices Guaranteed", price: 45 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "express", name: "Express (Priority)", price: 15 },
        ],
      },
      {
        id: "garden-salvation",
        name: "Garden of Salvation",
        description: "Complete Garden of Salvation and get Divinity exotic",
        basePrice: 35,
        completionTime: "2-3 hours",
        options: [
          { id: "divinity", name: "Divinity Guaranteed", price: 25 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "sherpa", name: "Sherpa Mode (Learn)", price: 10 },
        ],
      },
      {
        id: "deep-stone-crypt",
        name: "Deep Stone Crypt",
        description: "Complete Deep Stone Crypt and get Eyes of Tomorrow",
        basePrice: 32,
        completionTime: "1.5-2 hours",
        options: [
          { id: "eyes-tomorrow", name: "Eyes of Tomorrow", price: 40 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "flawless", name: "Flawless Run", price: 89 },
        ],
      },
      {
        id: "vault-glass",
        name: "Vault of Glass",
        description: "Complete Vault of Glass and get Vex Mythoclast",
        basePrice: 28,
        completionTime: "1-2 hours",
        options: [
          { id: "vex-mythoclast", name: "Vex Mythoclast", price: 55 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "catalyst", name: "Vex Catalyst", price: 25 },
        ],
      },
      {
        id: "vow-disciple",
        name: "Vow of the Disciple",
        description: "Complete Vow of the Disciple and get Collective Obligation",
        basePrice: 35,
        completionTime: "2-3 hours",
        options: [
          { id: "collective-obligation", name: "Collective Obligation", price: 45 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "red-border", name: "Red Border Weapons", price: 20 },
        ],
      },
      {
        id: "kings-fall",
        name: "King's Fall",
        description: "Complete King's Fall and get Touch of Malice",
        basePrice: 33,
        completionTime: "2-3 hours",
        options: [
          { id: "touch-malice", name: "Touch of Malice", price: 40 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "catalyst", name: "Touch of Malice Catalyst", price: 30 },
        ],
      },
    ],
  },
  "trials-flawless": {
    title: "Trials of Osiris",
    description: "Achieve flawless victory in Trials of Osiris",
    basePrice: 45,
    image: "/placeholder.svg?height=400&width=600&text=Trials+Flawless",
    rating: 4.8,
    completionTime: "2-4 hours",
    category: "PvP",
    services: [
      {
        id: "flawless-carry",
        name: "Flawless Carry (7-0)",
        description: "Get carried to flawless victory and lighthouse access",
        basePrice: 79,
        completionTime: "2-6 hours",
        options: [
          { id: "adept-weapons", name: "Specific Adept Weapon", price: 25 },
          { id: "stream", name: "Stream Service", price: 10 },
          { id: "express", name: "Express Service", price: 40 },
        ],
      },
      {
        id: "trials-wins",
        name: "Trials Wins",
        description: "Get specific number of wins in Trials",
        basePrice: 15,
        completionTime: "30min-2 hours",
        options: [
          { id: "3-wins", name: "3 Wins", price: 15 },
          { id: "5-wins", name: "5 Wins", price: 25 },
          { id: "7-wins", name: "7 Wins", price: 35 },
          { id: "stream", name: "Stream Service", price: 5 },
        ],
      },
      {
        id: "trials-coaching",
        name: "Trials Coaching",
        description: "Learn from professionals while playing",
        basePrice: 45,
        completionTime: "2-3 hours",
        options: [
          { id: "vod-review", name: "VOD Review", price: 20 },
          { id: "loadout-help", name: "Loadout Optimization", price: 10 },
          { id: "extended", name: "Extended Session", price: 25 },
        ],
      },
    ],
  },
  "dungeon-carries": {
    title: "Dungeon Carries",
    description: "Master all dungeons with expert guidance",
    basePrice: 15,
    image: "/placeholder.svg?height=400&width=600&text=Dungeon+Carries",
    rating: 4.9,
    completionTime: "30-90 min",
    category: "PvE",
    services: [
      {
        id: "duality",
        name: "Duality Dungeon",
        description: "Complete Duality dungeon and get exclusive rewards",
        basePrice: 19,
        completionTime: "45-90 min",
        options: [
          { id: "heartshadow", name: "Heartshadow Exotic", price: 35 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "master", name: "Master Difficulty", price: 25 },
        ],
      },
      {
        id: "grasp-avarice",
        name: "Grasp of Avarice",
        description: "Complete Grasp of Avarice and get Gjallarhorn catalyst",
        basePrice: 17,
        completionTime: "30-60 min",
        options: [
          { id: "gjallarhorn-catalyst", name: "Gjallarhorn Catalyst", price: 15 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "master", name: "Master Difficulty", price: 20 },
        ],
      },
      {
        id: "prophecy",
        name: "Prophecy Dungeon",
        description: "Complete Prophecy dungeon for exclusive armor and weapons",
        basePrice: 15,
        completionTime: "45-75 min",
        options: [
          { id: "solo-flawless", name: "Solo Flawless", price: 89 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "full-armor", name: "Full Armor Set", price: 25 },
        ],
      },
      {
        id: "pit-heresy",
        name: "Pit of Heresy",
        description: "Complete Pit of Heresy and get Xenophage exotic",
        basePrice: 14,
        completionTime: "30-45 min",
        options: [
          { id: "xenophage", name: "Xenophage Quest", price: 20 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "masterwork", name: "Masterwork Materials", price: 10 },
        ],
      },
      {
        id: "shattered-throne",
        name: "Shattered Throne",
        description: "Complete Shattered Throne and get Wish-Ender",
        basePrice: 16,
        completionTime: "45-60 min",
        options: [
          { id: "wish-ender", name: "Wish-Ender Quest", price: 25 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "solo-flawless", name: "Solo Flawless", price: 75 },
        ],
      },
      {
        id: "spire-watcher",
        name: "Spire of the Watcher",
        description: "Complete Spire of the Watcher dungeon",
        basePrice: 20,
        completionTime: "60-90 min",
        options: [
          { id: "hierarchy-needs", name: "Hierarchy of Needs", price: 40 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "master", name: "Master Difficulty", price: 30 },
        ],
      },
    ],
  },
  "exotic-quests": {
    title: "Exotic Quests",
    description: "Complete challenging exotic weapon quests",
    basePrice: 35,
    image: "/placeholder.svg?height=400&width=600&text=Exotic+Quests",
    rating: 4.9,
    completionTime: "2-6 hours",
    category: "Quests",
    services: [
      {
        id: "whirling-ovation",
        name: "Whirling Ovation Exotic Rocket Launcher",
        description: "Get the Whirling Ovation exotic rocket launcher",
        basePrice: 89,
        completionTime: "3-5 hours",
        options: [
          { id: "catalyst", name: "Obtain the Catalyst", price: 89 },
          { id: "masterwork", name: "Masterwork the Catalyst", price: 15 },
          { id: "stream", name: "I need a stream", price: 5 },
        ],
      },
      {
        id: "osteo-striga",
        name: "Osteo Striga Exotic SMG",
        description: "Get the Osteo Striga exotic submachine gun",
        basePrice: 45,
        completionTime: "2-3 hours",
        options: [
          { id: "catalyst", name: "Osteo Striga Catalyst", price: 25 },
          { id: "masterwork", name: "Masterwork the Catalyst", price: 15 },
          { id: "stream", name: "Stream Service", price: 5 },
        ],
      },
      {
        id: "parasite",
        name: "Parasite Exotic Grenade Launcher",
        description: "Complete the Parasite exotic quest",
        basePrice: 55,
        completionTime: "3-4 hours",
        options: [
          { id: "catalyst", name: "Parasite Catalyst", price: 35 },
          { id: "masterwork", name: "Masterwork the Catalyst", price: 15 },
          { id: "stream", name: "Stream Service", price: 5 },
        ],
      },
      {
        id: "grand-overture",
        name: "Grand Overture Exotic Machine Gun",
        description: "Get the Grand Overture exotic machine gun",
        basePrice: 65,
        completionTime: "4-6 hours",
        options: [
          { id: "catalyst", name: "Grand Overture Catalyst", price: 45 },
          { id: "masterwork", name: "Masterwork the Catalyst", price: 15 },
          { id: "stream", name: "Stream Service", price: 5 },
        ],
      },
      {
        id: "dead-messenger",
        name: "Dead Messenger Exotic Grenade Launcher",
        description: "Complete the Dead Messenger exotic quest",
        basePrice: 40,
        completionTime: "2-3 hours",
        options: [
          { id: "catalyst", name: "Dead Messenger Catalyst", price: 30 },
          { id: "masterwork", name: "Masterwork the Catalyst", price: 15 },
          { id: "stream", name: "Stream Service", price: 5 },
        ],
      },
    ],
  },
  "grandmaster-nightfalls": {
    title: "Grandmaster Nightfalls",
    description: "Conquer the toughest PvE content",
    basePrice: 20,
    image: "/placeholder.svg?height=400&width=600&text=GM+Nightfalls",
    rating: 4.8,
    completionTime: "45-90 min",
    category: "PvE",
    services: [
      {
        id: "single-gm",
        name: "Single GM Nightfall",
        description: "Complete one Grandmaster Nightfall",
        basePrice: 24,
        completionTime: "30-60 min",
        options: [
          { id: "adept-weapon", name: "Specific Adept Weapon", price: 15 },
          { id: "stream", name: "Stream Service", price: 5 },
          { id: "platinum", name: "Platinum Rewards", price: 10 },
        ],
      },
      {
        id: "conqueror-seal",
        name: "Conqueror Seal",
        description: "Complete all GM Nightfalls for Conqueror seal",
        basePrice: 149,
        completionTime: "1-2 weeks",
        options: [
          { id: "gilded", name: "Gilded Conqueror", price: 50 },
          { id: "stream", name: "Stream Service", price: 25 },
          { id: "express", name: "Express Service", price: 75 },
        ],
      },
      {
        id: "weekly-gm-farm",
        name: "Weekly GM Farm",
        description: "Farm the weekly GM Nightfall multiple times",
        basePrice: 39,
        completionTime: "3-5 hours",
        options: [
          { id: "5-runs", name: "5 Completions", price: 39 },
          { id: "10-runs", name: "10 Completions", price: 69 },
          { id: "stream", name: "Stream Service", price: 10 },
        ],
      },
    ],
  },
  "power-leveling": {
    title: "Power Leveling",
    description: "Reach maximum power level quickly",
    basePrice: 30,
    image: "/placeholder.svg?height=400&width=600&text=Power+Leveling",
    rating: 4.7,
    completionTime: "1-2 days",
    category: "Leveling",
    services: [
      {
        id: "soft-cap",
        name: "Soft Cap Leveling (1800)",
        description: "Level up to the soft cap quickly",
        basePrice: 39,
        completionTime: "1-2 days",
        options: [
          { id: "express", name: "Express Service", price: 20 },
          { id: "stream", name: "Stream Service", price: 10 },
          { id: "specific-gear", name: "Specific Gear Focus", price: 15 },
        ],
      },
      {
        id: "hard-cap",
        name: "Hard Cap Leveling (1810)",
        description: "Level up to the hard cap",
        basePrice: 69,
        completionTime: "3-5 days",
        options: [
          { id: "express", name: "Express Service", price: 35 },
          { id: "stream", name: "Stream Service", price: 15 },
          { id: "high-stat-armor", name: "High-Stat Armor Focus", price: 25 },
        ],
      },
      {
        id: "pinnacle-cap",
        name: "Pinnacle Cap (1820)",
        description: "Reach maximum power level",
        basePrice: 99,
        completionTime: "1-2 weeks",
        options: [
          { id: "express", name: "Express Service", price: 50 },
          { id: "stream", name: "Stream Service", price: 20 },
          { id: "god-roll-hunt", name: "God Roll Hunting", price: 40 },
        ],
      },
    ],
  },
}

interface ServiceDetailPageProps {
  serviceId: string
}

export function ServiceDetailPage({ serviceId }: ServiceDetailPageProps) {
  const [selectedService, setSelectedService] = useState<string>("")
  const [selectedOptions, setSelectedOptions] = useState<string[]>([])
  const [customRequest, setCustomRequest] = useState("")
  const [platform, setPlatform] = useState("")
  const { addItem } = useCart()

  const serviceData = servicesData[serviceId as keyof typeof servicesData]

  if (!serviceData) {
    return (
      <div className="min-h-screen bg-gray-900">
        <Header />
        <main className="py-12">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold text-white mb-4">Service Not Found</h1>
            <Link href="/services">
              <Button className="bg-blue-600 hover:bg-blue-700">Back to Services</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const currentService = serviceData.services.find((s) => s.id === selectedService)

  const calculateTotalPrice = () => {
    let total = currentService?.basePrice || serviceData.basePrice
    if (currentService) {
      selectedOptions.forEach((optionId) => {
        const option = currentService.options.find((opt) => opt.id === optionId)
        if (option) total += option.price
      })
    }
    return total
  }

  const handleAddToCart = () => {
    if (!currentService) return

    const optionsText =
      selectedOptions.length > 0
        ? ` + ${selectedOptions
            .map((optId) => currentService.options.find((opt) => opt.id === optId)?.name)
            .join(", ")}`
        : ""

    addItem({
      id: `${serviceId}-${selectedService}-${Date.now()}`,
      name: `${currentService.name}${optionsText}`,
      price: calculateTotalPrice(),
      quantity: 1,
      image: serviceData.image,
    })
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />

      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          {/* Breadcrumb */}
          <div className="mb-8">
            <Link href="/services" className="flex items-center text-blue-400 hover:text-blue-300 mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Services
            </Link>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Service Selection */}
            <div className="lg:col-span-2 space-y-6">
              {/* Header */}
              <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-white mb-4">{serviceData.title}</h1>
                <p className="text-xl text-gray-300">{serviceData.description}</p>
                <div className="flex items-center justify-center space-x-4 mt-4">
                  <div className="flex items-center space-x-1">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="text-white font-medium">{serviceData.rating}</span>
                  </div>
                  <Badge className="bg-blue-600 text-white">{serviceData.category}</Badge>
                </div>
              </div>

              {/* Trust Badge */}
              <div className="bg-green-900/30 border border-green-700 rounded-lg p-4 text-center mb-8">
                <div className="flex items-center justify-center space-x-4">
                  <span className="text-green-300 font-medium">Trusted by thousands</span>
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-green-400 text-green-400" />
                    ))}
                  </div>
                  <span className="text-green-300">Over 10,300 reviews</span>
                </div>
              </div>

              {/* Service Selection */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Select Service</CardTitle>
                  <CardDescription className="text-gray-400">Choose the specific service you need</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {serviceData.services.map((service) => (
                    <div
                      key={service.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        selectedService === service.id
                          ? "border-blue-500 bg-blue-900/20"
                          : "border-gray-600 hover:border-gray-500"
                      }`}
                      onClick={() => {
                        setSelectedService(service.id)
                        setSelectedOptions([])
                      }}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-semibold text-white">{service.name}</h3>
                          <p className="text-gray-400 text-sm mb-2">{service.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-400">
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>{service.completionTime}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Shield className="w-4 h-4" />
                              <span>Safe & Secure</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-400">${service.basePrice}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Options */}
              {currentService && (
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Recommended Options</CardTitle>
                    <CardDescription className="text-gray-400">
                      Enhance your service with additional options
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {currentService.options.map((option) => (
                      <div
                        key={option.id}
                        className="flex items-center justify-between p-3 border border-gray-600 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <Checkbox
                            id={option.id}
                            checked={selectedOptions.includes(option.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedOptions([...selectedOptions, option.id])
                              } else {
                                setSelectedOptions(selectedOptions.filter((id) => id !== option.id))
                              }
                            }}
                          />
                          <label htmlFor={option.id} className="text-white font-medium cursor-pointer">
                            {option.name}
                          </label>
                        </div>
                        <div className="text-blue-400 font-semibold">+${option.price}</div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Custom Request */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Custom Request</CardTitle>
                  <CardDescription className="text-gray-400">
                    Write your request here to customize: ETAs, Schedule, RNG, Progress discounts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder="Describe any specific requirements or preferences..."
                    value={customRequest}
                    onChange={(e) => setCustomRequest(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                    rows={4}
                  />
                </CardContent>
              </Card>

              {/* Platform Selection */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Platform</CardTitle>
                  <CardDescription className="text-gray-400">Select your gaming platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Select your platform" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      <SelectItem value="pc" className="text-white hover:bg-gray-600">
                        PC (Steam/Epic)
                      </SelectItem>
                      <SelectItem value="xbox" className="text-white hover:bg-gray-600">
                        Xbox
                      </SelectItem>
                      <SelectItem value="playstation" className="text-white hover:bg-gray-600">
                        PlayStation
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="bg-gray-800 border-gray-700 sticky top-24">
                <CardHeader>
                  <CardTitle className="text-white">What you get</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {currentService ? (
                    <>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-green-400" />
                          <span className="text-white">Desired {currentService.name.toLowerCase()}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-green-400" />
                          <span className="text-white">All items and resources that might drop</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-green-400" />
                          <span className="text-white">Experience for Season Pass and Artifact</span>
                        </div>
                        {selectedOptions.map((optionId) => {
                          const option = currentService.options.find((opt) => opt.id === optionId)
                          return option ? (
                            <div key={optionId} className="flex items-center space-x-2">
                              <Plus className="w-5 h-5 text-blue-400" />
                              <span className="text-white">{option.name}</span>
                            </div>
                          ) : null
                        })}
                      </div>

                      <div className="border-t border-gray-600 pt-4">
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-gray-400">Estimated time:</span>
                          <span className="text-white">{currentService.completionTime}</span>
                        </div>
                        <div className="flex justify-between items-center text-2xl font-bold">
                          <span className="text-white">Total:</span>
                          <span className="text-blue-400">${calculateTotalPrice()}</span>
                        </div>
                      </div>

                      <Button
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg font-semibold"
                        onClick={handleAddToCart}
                        disabled={!platform}
                      >
                        Add to Cart
                      </Button>

                      <div className="text-center text-sm text-gray-400">Select platform to continue</div>
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-400 mb-4">Select a service to see details</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
