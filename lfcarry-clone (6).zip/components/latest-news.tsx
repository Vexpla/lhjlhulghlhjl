import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronRight, Calendar } from "lucide-react"
import Link from "next/link"

export function LatestNews() {
  const news = [
    {
      title: "New Valorant Boosting Services Available",
      excerpt:
        "We've expanded our Valorant boosting services to include the latest Act. Check out our competitive pricing and fast delivery times.",
      image: "/placeholder.svg?height=200&width=400",
      date: "June 15, 2024",
      category: "New Services",
      url: "/blog/new-valorant-boosting-services",
    },
    {
      title: "Meet Our New Challenger League of Legends Boosters",
      excerpt:
        "We've added 5 new Challenger-ranked boosters to our team to ensure even faster delivery times for high-elo orders.",
      image: "/placeholder.svg?height=200&width=400",
      date: "June 10, 2024",
      category: "Team Updates",
      url: "/blog/new-challenger-boosters",
    },
    {
      title: "Summer Sale: 20% Off All Boosting Services",
      excerpt:
        "For a limited time, enjoy 20% off all our boosting services. Use code SUMMER20 at checkout to claim your discount.",
      image: "/placeholder.svg?height=200&width=400",
      date: "June 5, 2024",
      category: "Promotions",
      url: "/blog/summer-sale",
    },
  ]

  return (
    <section className="py-20 px-4 bg-[#0D1117]">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Latest News & Updates</h2>
            <p className="text-gray-400 max-w-2xl">
              Stay up to date with our latest services, promotions, and gaming news
            </p>
          </div>
          <Button variant="link" className="text-purple-400 hover:text-purple-300 p-0 h-auto flex items-center">
            View All Posts <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {news.map((item, index) => (
            <Card
              key={index}
              className="bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-purple-500/50 transition-all duration-300 overflow-hidden group"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <Badge className="bg-purple-600/20 text-purple-400 hover:bg-purple-600/30">{item.category}</Badge>
                  <div className="flex items-center text-gray-400 text-sm">
                    <Calendar className="h-4 w-4 mr-1" />
                    {item.date}
                  </div>
                </div>
                <Link href={item.url} className="block">
                  <h3 className="text-xl font-bold text-white mb-2 hover:text-purple-400 transition-colors">
                    {item.title}
                  </h3>
                </Link>
                <p className="text-gray-400 mb-4 line-clamp-2">{item.excerpt}</p>
                <Link href={item.url} className="text-purple-400 hover:text-purple-300 font-medium flex items-center">
                  Read More <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
