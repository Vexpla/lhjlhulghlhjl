"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Sidebar() {
  const [selectedGame, setSelectedGame] = useState("destiny-2")

  const games = [{ id: "destiny-2", name: "Destiny 2", active: true }]

  const categories = [
    { name: "Raids", href: "/services/raids" },
    { name: "Dungeons", href: "/services/dungeons" },
    { name: "Trials of Osiris", href: "/services/trials" },
    { name: "Grandmaster Nightfalls", href: "/services/nightfalls" },
    { name: "Seals & Titles", href: "/services/seals" },
    { name: "Power Leveling", href: "/services/power-leveling" },
    { name: "Exotic Quests", href: "/services/exotic-quests" },
    { name: "Seasonal Activities", href: "/services/seasonal" },
    { name: "PvP Services", href: "/services/pvp" },
    { name: "Account Recovery", href: "/services/recovery" },
  ]

  return (
    <aside className="w-64 bg-gray-800 border-r border-gray-700 min-h-screen pt-4">
      <div className="px-6">
        <h2 className="text-lg font-semibold text-white mb-4">Games</h2>

        {/* Game Selection */}
        <div className="space-y-2 mb-6">
          {games.map((game) => (
            <Button
              key={game.id}
              variant={game.active ? "default" : "ghost"}
              className={`w-full justify-start text-left h-12 ${
                game.active ? "bg-pink-600 hover:bg-pink-700 text-white" : "bg-gray-700 hover:bg-gray-600 text-gray-300"
              }`}
              onClick={() => setSelectedGame(game.id)}
            >
              {game.name}
            </Button>
          ))}
        </div>

        {/* Categories */}
        {selectedGame === "destiny-2" && (
          <div className="space-y-1">
            <h3 className="text-sm font-medium text-gray-400 mb-3 uppercase tracking-wide">Categories</h3>
            {categories.map((category, index) => (
              <Link key={index} href={category.href}>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-left h-10 text-gray-300 hover:bg-gray-700 hover:text-white"
                >
                  {category.name}
                </Button>
              </Link>
            ))}
          </div>
        )}
      </div>
    </aside>
  )
}
