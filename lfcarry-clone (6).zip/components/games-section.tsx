import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function GamesSection() {
  const games = [
    {
      name: "League of Legends",
      image: "/placeholder.svg?height=200&width=300",
      popular: true,
    },
    {
      name: "Valorant",
      image: "/placeholder.svg?height=200&width=300",
      popular: true,
    },
    {
      name: "CS2",
      image: "/placeholder.svg?height=200&width=300",
      popular: false,
    },
    {
      name: "Apex Legends",
      image: "/placeholder.svg?height=200&width=300",
      popular: false,
    },
    {
      name: "Overwatch 2",
      image: "/placeholder.svg?height=200&width=300",
      popular: false,
    },
    {
      name: "Rocket League",
      image: "/placeholder.svg?height=200&width=300",
      popular: false,
    },
  ]

  return (
    <section id="games" className="py-20 px-4 bg-black/20">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Available Games</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            We offer boosting services for the most popular games of the moment
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game, index) => (
            <Card
              key={index}
              className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 hover:transform hover:scale-105 overflow-hidden"
            >
              <div className="relative">
                <img src={game.image || "/placeholder.svg"} alt={game.name} className="w-full h-48 object-cover" />
                {game.popular && (
                  <div className="absolute top-4 right-4 bg-purple-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    Popular
                  </div>
                )}
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-white mb-4">{game.name}</h3>
                <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">View Services</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
