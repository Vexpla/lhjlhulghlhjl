"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"

export function Testimonials() {
  const [currentPage, setCurrentPage] = useState(0)

  const testimonials = [
    {
      name: "Guardian_Jake",
      avatar: "/placeholder.svg?height=60&width=60",
      rating: 5,
      text: "Amazing raid carry! Got my first clear of the new raid and the team was super patient and explained all the mechanics. Definitely using them again!",
      service: "Raid Carry",
      date: "2 days ago",
      verified: true,
    },
    {
      name: "TrialsNoob_Emma",
      avatar: "/placeholder.svg?height=60&width=60",
      rating: 5,
      text: "Went flawless for the first time ever! The team carried me through trials and I got the adept weapons I wanted. Professional service!",
      service: "Trials Flawless",
      date: "1 week ago",
      verified: true,
    },
    {
      name: "PowerLevel_Mike",
      avatar: "/placeholder.svg?height=60&width=60",
      rating: 5,
      text: "Power leveling service was incredibly fast. Went from 1750 to pinnacle cap in just a few days. Great communication throughout.",
      service: "Power Leveling",
      date: "3 days ago",
      verified: true,
    },
    {
      name: "SealHunter_Sarah",
      avatar: "/placeholder.svg?height=60&width=60",
      rating: 4,
      text: "Got my Conqueror seal finally! The GM nightfall carries were smooth and the team knew all the strategies. Worth every penny.",
      service: "GM Nightfall",
      date: "2 weeks ago",
      verified: true,
    },
    {
      name: "Dungeon_David",
      avatar: "/placeholder.svg?height=60&width=60",
      rating: 5,
      text: "Master dungeon carries were perfect. Got all the weapons I needed and the team was very skilled. Fast and professional.",
      service: "Dungeon Carry",
      date: "5 days ago",
      verified: true,
    },
    {
      name: "NewLight_Lisa",
      avatar: "/placeholder.svg?height=60&width=60",
      rating: 5,
      text: "As a new player, the sherpa service was incredible. They taught me the mechanics and I actually learned how to do the content myself!",
      service: "Sherpa Service",
      date: "1 month ago",
      verified: true,
    },
  ]

  const itemsPerPage = 3
  const totalPages = Math.ceil(testimonials.length / itemsPerPage)
  const currentTestimonials = testimonials.slice(currentPage * itemsPerPage, (currentPage + 1) * itemsPerPage)

  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % totalPages)
  }

  const prevPage = () => {
    setCurrentPage((prev) => (prev - 1 + totalPages) % totalPages)
  }

  return (
    <section className="py-20 px-4 bg-[#0D1117]">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">What Our Guardians Say</h2>
            <p className="text-gray-400 max-w-2xl">
              Thousands of satisfied Destiny 2 players trust us for their boosting and carry needs
            </p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <Button
              variant="outline"
              size="icon"
              className="border-gray-700 text-gray-400 hover:text-white hover:border-orange-500 bg-transparent"
              onClick={prevPage}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="border-gray-700 text-gray-400 hover:text-white hover:border-orange-500 bg-transparent"
              onClick={nextPage}
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {currentTestimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-orange-500/50 transition-all duration-300"
            >
              <CardContent className="p-6 relative">
                <Quote className="absolute top-6 right-6 h-8 w-8 text-orange-500/20" />
                <div className="flex items-center mb-4">
                  <Avatar className="h-12 w-12 mr-4 border border-gray-700">
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback className="bg-orange-900 text-white">{testimonial.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center">
                      <h4 className="text-white font-semibold">{testimonial.name}</h4>
                      {testimonial.verified && (
                        <Badge className="ml-2 bg-green-600/20 text-green-400 hover:bg-green-600/30 text-xs">
                          Verified
                        </Badge>
                      )}
                    </div>
                    <p className="text-orange-400 text-sm">Destiny 2 Player</p>
                  </div>
                </div>

                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}`}
                    />
                  ))}
                </div>

                <p className="text-gray-300 mb-4">"{testimonial.text}"</p>

                <div className="flex justify-between items-center text-sm">
                  <Badge variant="outline" className="bg-gray-800/50 text-gray-300 border-gray-700">
                    {testimonial.service}
                  </Badge>
                  <span className="text-gray-500">{testimonial.date}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-center mt-8">
          <div className="flex space-x-2">
            {[...Array(totalPages)].map((_, index) => (
              <Button
                key={index}
                variant="outline"
                size="icon"
                className={`border-gray-700 text-gray-400 hover:text-white hover:border-orange-500 bg-transparent ${
                  index === currentPage ? "bg-orange-500/20" : ""
                }`}
                onClick={() => setCurrentPage(index)}
              >
                {index + 1}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
