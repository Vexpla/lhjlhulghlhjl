"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

export function FAQ() {
  const faqs = [
    {
      question: "How does the boosting process work?",
      answer:
        "After placing your order, we'll match you with a professional booster who specializes in your game and requirements. They'll begin working on your account within 1-2 hours. You can track progress in real-time through your dashboard and communicate with your booster via our secure messaging system.",
    },
    {
      question: "Is boosting safe for my account?",
      answer:
        "Yes, we take multiple security measures to ensure your account stays safe. Our boosters use VPNs that match your location, maintain similar playing patterns, and never use any third-party software that could trigger bans. We've completed over 50,000 orders with a 0% ban rate.",
    },
    {
      question: "How long will my order take to complete?",
      answer:
        "The completion time depends on the service you choose, your current rank, and your desired rank. For example, a boost from Gold to Platinum typically takes 2-3 days. You can see the estimated completion time before placing your order, and you can also choose priority boosting for faster delivery.",
    },
    {
      question: "Can I play on my account while it's being boosted?",
      answer:
        "We recommend not playing on your account during the boosting process to avoid any conflicts or delays. However, if you need to play, please inform your booster through the messaging system so they can pause the boost temporarily.",
    },
    {
      question: "What payment methods do you accept?",
      answer:
        "We accept all major credit cards, PayPal, cryptocurrency (Bitcoin, Ethereum), and various regional payment methods. All payments are processed securely, and we don't store your payment information.",
    },
    {
      question: "What if I'm not satisfied with the service?",
      answer:
        "Customer satisfaction is our top priority. If you're not happy with our service, please contact our support team within 24 hours of order completion. We offer a money-back guarantee for eligible cases and will work with you to resolve any issues.",
    },
  ]

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Frequently Asked Questions</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Find answers to common questions about our boosting and coaching services
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-gradient-to-b from-gray-900 to-gray-950 border border-gray-800 rounded-lg overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 text-white hover:text-purple-400 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-gray-300">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-10 text-center">
            <p className="text-gray-400 mb-4">
              Still have questions? Our support team is available 24/7 to assist you.
            </p>
            <Button className="bg-purple-600 hover:bg-purple-700 text-white">
              Contact Support
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
