import Link from "next/link"
import { Facebook, Twitter, Instagram, Youtube } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-black text-white py-16 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">EC</span>
              </div>
              <span className="text-xl font-bold">EliteCarry.top</span>
            </div>
            <p className="text-gray-400 text-sm">
              Professional Destiny 2 boosting services with guaranteed results and 24/7 support.
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              <Twitter className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              <Instagram className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              <Youtube className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/services/raid-carries" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Raid Carries
                </Link>
              </li>
              <li>
                <Link href="/services/trials-flawless" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Trials Flawless
                </Link>
              </li>
              <li>
                <Link href="/services/dungeon-carries" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Dungeon Carries
                </Link>
              </li>
              <li>
                <Link
                  href="/services/grandmaster-nightfalls"
                  className="text-gray-400 hover:text-blue-400 transition-colors"
                >
                  GM Nightfalls
                </Link>
              </li>
              <li>
                <Link href="/services/power-leveling" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Power Leveling
                </Link>
              </li>
              <li>
                <Link href="/services/exotic-quests" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Exotic Quests
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Support</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/faq" className="text-gray-400 hover:text-blue-400 transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/reviews" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Reviews
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-400 hover:text-blue-400 transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>Email: support@elitecarry.top</li>
              <li>Discord: EliteCarry#1234</li>
              <li>Available 24/7</li>
              <li>Response time: &lt; 30 minutes</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 EliteCarry.top. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
