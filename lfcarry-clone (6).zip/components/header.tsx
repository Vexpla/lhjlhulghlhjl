"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { useRouter, usePathname } from "next/navigation"
import { Search, ShoppingCart, User, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/hooks/use-auth"
import { useCart } from "@/hooks/use-cart"

// Datos de servicios para las sugerencias
const searchableServices = [
  { id: "last-wish", title: "Last Wish Raid", category: "Raids", price: 29 },
  { id: "garden-salvation", title: "Garden of Salvation", category: "Raids", price: 35 },
  { id: "deep-stone-crypt", title: "Deep Stone Crypt", category: "Raids", price: 32 },
  { id: "vault-glass", title: "Vault of Glass", category: "Raids", price: 28 },
  { id: "vow-disciple", title: "Vow of the Disciple", category: "Raids", price: 35 },
  { id: "kings-fall", title: "King's Fall", category: "Raids", price: 33 },
  { id: "flawless-carry", title: "Trials Flawless (7-0)", category: "PvP", price: 79 },
  { id: "trials-wins", title: "Trials Wins", category: "PvP", price: 15 },
  { id: "trials-coaching", title: "Trials Coaching", category: "PvP", price: 45 },
  { id: "duality", title: "Duality Dungeon", category: "Dungeons", price: 19 },
  { id: "grasp-avarice", title: "Grasp of Avarice", category: "Dungeons", price: 17 },
  { id: "prophecy", title: "Prophecy Dungeon", category: "Dungeons", price: 15 },
  { id: "pit-heresy", title: "Pit of Heresy", category: "Dungeons", price: 14 },
  { id: "shattered-throne", title: "Shattered Throne", category: "Dungeons", price: 16 },
  { id: "spire-watcher", title: "Spire of the Watcher", category: "Dungeons", price: 20 },
  { id: "whirling-ovation", title: "Whirling Ovation Exotic Rocket Launcher", category: "Exotic Quests", price: 89 },
  { id: "osteo-striga", title: "Osteo Striga Exotic SMG", category: "Exotic Quests", price: 45 },
  { id: "parasite", title: "Parasite Exotic Grenade Launcher", category: "Exotic Quests", price: 55 },
  { id: "grand-overture", title: "Grand Overture Exotic Machine Gun", category: "Exotic Quests", price: 65 },
  { id: "dead-messenger", title: "Dead Messenger Exotic Grenade Launcher", category: "Exotic Quests", price: 40 },
  { id: "single-gm", title: "Single GM Nightfall", category: "GM Nightfalls", price: 24 },
  { id: "conqueror-seal", title: "Conqueror Seal", category: "GM Nightfalls", price: 149 },
  { id: "weekly-gm-farm", title: "Weekly GM Farm", category: "GM Nightfalls", price: 39 },
  { id: "soft-cap", title: "Soft Cap Leveling (1800)", category: "Power Leveling", price: 39 },
  { id: "hard-cap", title: "Hard Cap Leveling (1810)", category: "Power Leveling", price: 69 },
  { id: "pinnacle-cap", title: "Pinnacle Cap (1820)", category: "Power Leveling", price: 99 },
]

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [suggestions, setSuggestions] = useState<typeof searchableServices>([])
  const { user, logout } = useAuth()
  const { items } = useCart()
  const router = useRouter()
  const pathname = usePathname()
  const searchRef = useRef<HTMLDivElement>(null)

  const cartItemsCount = items.reduce((sum, item) => sum + item.quantity, 0)

  // Actualizar sugerencias cuando cambia la búsqueda
  useEffect(() => {
    if (searchQuery.trim().length > 0) {
      const filtered = searchableServices
        .filter(
          (service) =>
            service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            service.category.toLowerCase().includes(searchQuery.toLowerCase()),
        )
        .slice(0, 6) // Mostrar máximo 6 sugerencias

      setSuggestions(filtered)
      setShowSuggestions(true)
    } else {
      setSuggestions([])
      setShowSuggestions(false)
    }
  }, [searchQuery])

  // Cerrar sugerencias al hacer clic fuera
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleSearch = (query: string) => {
    if (query.trim()) {
      // Navegar a la página de servicios con el parámetro de búsqueda
      router.push(`/services?search=${encodeURIComponent(query.trim())}`)
      setShowSuggestions(false)
      setSearchQuery("")
    }
  }

  const handleSuggestionClick = (service: (typeof searchableServices)[0]) => {
    setSearchQuery("")
    setShowSuggestions(false)
    // CAMBIO AQUÍ: Ahora va directamente al servicio individual
    router.push(`/service/${service.id}`)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleSearch(searchQuery)
    }
  }

  return (
    <header className="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">EC</span>
            </div>
            <span className="text-xl font-bold text-white">EliteCarry.top</span>
          </Link>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-lg mx-8 relative" ref={searchRef}>
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                onFocus={() => searchQuery.length > 0 && setShowSuggestions(true)}
                className="pl-10 pr-4 py-2 w-full bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />

              {/* Sugerencias */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-gray-600 rounded-md shadow-lg z-50 max-h-80 overflow-y-auto">
                  {suggestions.map((service) => (
                    <div
                      key={service.id}
                      onClick={() => handleSuggestionClick(service)}
                      className="px-4 py-3 hover:bg-gray-700 cursor-pointer border-b border-gray-700 last:border-b-0"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-white font-medium">{service.title}</div>
                          <div className="text-sm text-gray-400">{service.category}</div>
                        </div>
                        <div className="text-blue-400 font-semibold">${service.price}</div>
                      </div>
                    </div>
                  ))}

                  {searchQuery.trim() && (
                    <div
                      onClick={() => handleSearch(searchQuery)}
                      className="px-4 py-3 hover:bg-gray-700 cursor-pointer border-t border-gray-600 bg-gray-750"
                    >
                      <div className="flex items-center text-blue-400">
                        <Search className="w-4 h-4 mr-2" />
                        <span>Search for "{searchQuery}"</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/services" className="text-gray-300 hover:text-blue-400 font-medium">
              Services
            </Link>
            <Link href="/reviews" className="text-gray-300 hover:text-blue-400 font-medium">
              Reviews
            </Link>
            <Link href="/faq" className="text-gray-300 hover:text-blue-400 font-medium">
              FAQ
            </Link>
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Cart */}
            <Link href="/cart" className="relative">
              <Button variant="ghost" size="sm" className="p-2 text-gray-300 hover:text-white">
                <ShoppingCart className="w-5 h-5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartItemsCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* User Menu */}
            {user ? (
              <div className="relative group">
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex items-center space-x-2 text-gray-300 hover:text-white"
                >
                  <User className="w-4 h-4" />
                  <span className="hidden sm:inline">{user.name}</span>
                </Button>
                <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg py-1 z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border border-gray-700">
                  <Link href="/dashboard" className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700">
                    Dashboard
                  </Link>
                  <Link href="/orders" className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700">
                    My Orders
                  </Link>
                  <button
                    onClick={logout}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                  >
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/login">
                  <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white">
                    Login
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden p-2 text-gray-300 hover:text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-700">
            {/* Mobile Search */}
            <div className="mb-4 relative" ref={searchRef}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Search services..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  onFocus={() => searchQuery.length > 0 && setShowSuggestions(true)}
                  className="pl-10 pr-4 py-2 w-full bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                />

                {/* Sugerencias móviles */}
                {showSuggestions && suggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-gray-600 rounded-md shadow-lg z-50 max-h-60 overflow-y-auto">
                    {suggestions.map((service) => (
                      <div
                        key={service.id}
                        onClick={() => handleSuggestionClick(service)}
                        className="px-4 py-3 hover:bg-gray-700 cursor-pointer border-b border-gray-700 last:border-b-0"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-white font-medium text-sm">{service.title}</div>
                            <div className="text-xs text-gray-400">{service.category}</div>
                          </div>
                          <div className="text-blue-400 font-semibold text-sm">${service.price}</div>
                        </div>
                      </div>
                    ))}

                    {searchQuery.trim() && (
                      <div
                        onClick={() => handleSearch(searchQuery)}
                        className="px-4 py-3 hover:bg-gray-700 cursor-pointer border-t border-gray-600"
                      >
                        <div className="flex items-center text-blue-400">
                          <Search className="w-4 h-4 mr-2" />
                          <span className="text-sm">Search for "{searchQuery}"</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Mobile Navigation */}
            <nav className="space-y-2">
              <Link href="/services" className="block py-2 text-gray-300 hover:text-blue-400">
                Services
              </Link>
              <Link href="/reviews" className="block py-2 text-gray-300 hover:text-blue-400">
                Reviews
              </Link>
              <Link href="/faq" className="block py-2 text-gray-300 hover:text-blue-400">
                FAQ
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
