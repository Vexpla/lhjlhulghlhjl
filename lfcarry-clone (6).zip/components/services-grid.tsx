"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, Clock, Shield } from "lucide-react"
import Link from "next/link"
import { useCart } from "@/hooks/use-cart"

const services = [
  {
    id: "raid-carries",
    title: "Raid Carries",
    description: "Complete any raid with our professional team",
    price: "From $25",
    image: "/placeholder.svg?height=200&width=300&text=Raid+Carries",
    features: ["All Raids Available", "Guaranteed Completion", "Loot Included"],
    rating: 4.9,
    completionTime: "1-3 hours",
    category: "PvE",
  },
  {
    id: "trials-flawless",
    title: "Trials Flawless",
    description: "Achieve flawless victory in Trials of Osiris",
    price: "From $45",
    image: "/placeholder.svg?height=200&width=300&text=Trials+Flawless",
    features: ["Flawless Guaranteed", "Adept Weapons", "Professional Players"],
    rating: 4.8,
    completionTime: "2-4 hours",
    category: "PvP",
  },
  {
    id: "dungeon-carries",
    title: "Dungeon Carries",
    description: "Master all dungeons with expert guidance",
    price: "From $15",
    image: "/placeholder.svg?height=200&width=300&text=Dungeon+Carries",
    features: ["All Dungeons", "Exotic Chances", "Fast Completion"],
    rating: 4.9,
    completionTime: "30-90 min",
    category: "PvE",
  },
  {
    id: "grandmaster-nightfalls",
    title: "Grandmaster Nightfalls",
    description: "Conquer the toughest PvE content",
    price: "From $20",
    image: "/placeholder.svg?height=200&width=300&text=GM+Nightfalls",
    features: ["Adept Weapons", "Ascendant Shards", "Safe Completion"],
    rating: 4.8,
    completionTime: "45-90 min",
    category: "PvE",
  },
  {
    id: "power-leveling",
    title: "Power Leveling",
    description: "Reach maximum power level quickly",
    price: "From $30",
    image: "/placeholder.svg?height=200&width=300&text=Power+Leveling",
    features: ["Fast Leveling", "Efficient Routes", "All Activities"],
    rating: 4.7,
    completionTime: "1-2 days",
    category: "Leveling",
  },
  {
    id: "exotic-quests",
    title: "Exotic Quests",
    description: "Complete challenging exotic weapon quests",
    price: "From $35",
    image: "/placeholder.svg?height=200&width=300&text=Exotic+Quests",
    features: ["All Exotic Quests", "Catalyst Included", "Step-by-Step"],
    rating: 4.9,
    completionTime: "2-6 hours",
    category: "Quests",
  },
]

export function ServicesGrid() {
  const { addItem } = useCart()

  const handleAddToCart = (service: (typeof services)[0]) => {
    addItem({
      id: service.id,
      name: service.title,
      price: Number.parseInt(service.price.replace(/[^0-9]/g, "")),
      quantity: 1,
      image: service.image,
    })
  }

  return (
    <section className="py-20 px-4 bg-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Services</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Professional Destiny 2 boosting services with guaranteed results and 24/7 support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <Card
              key={service.id}
              className="bg-gradient-to-b from-gray-800 to-gray-900 border-gray-600 overflow-hidden hover:shadow-2xl hover:border-blue-500 transition-all duration-300 transform hover:scale-105"
            >
              <div className="relative">
                <img
                  src={service.image || "/placeholder.svg"}
                  alt={service.title}
                  className="w-full h-48 object-cover"
                />
                <Badge className="absolute top-3 left-3 bg-blue-600 text-white font-semibold">{service.category}</Badge>
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
              </div>

              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-bold text-white">{service.title}</CardTitle>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium text-gray-300">{service.rating}</span>
                  </div>
                </div>
                <CardDescription className="text-gray-400">{service.description}</CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{service.completionTime}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Shield className="w-4 h-4" />
                    <span>Safe</span>
                  </div>
                </div>

                <ul className="space-y-2">
                  {service.features.map((feature, index) => (
                    <li key={index} className="text-sm text-gray-300 flex items-center">
                      <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="flex items-center justify-between pt-4 border-t border-gray-600">
                  <div className="text-2xl font-bold text-blue-400">{service.price}</div>
                  <div className="flex space-x-2">
                    <Link href={`/services/${service.id}`}>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-gray-500 text-gray-300 hover:bg-gray-700 hover:text-white bg-transparent"
                      >
                        View Details
                      </Button>
                    </Link>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold"
                      onClick={() => handleAddToCart(service)}
                    >
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16">
          <Link href="/services">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-10 py-4 text-lg font-semibold"
            >
              View All Services
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
