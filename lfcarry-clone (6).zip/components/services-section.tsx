import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trophy, Target, Users, Zap } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: Trophy,
      title: "Rank Boosting",
      description: "Climb ranks quickly with our professional players",
      features: ["All ranks available", "Real-time progress", "No ban risk"],
    },
    {
      icon: Target,
      title: "Placement Matches",
      description: "Get the best possible rank in your placement matches",
      features: ["10 guaranteed matches", "Optimized strategy", "Maximum rank possible"],
    },
    {
      icon: Users,
      title: "Duo Queue",
      description: "Play alongside a professional and learn while you climb",
      features: ["Learn while playing", "Discord communication", "Personalized tips"],
    },
    {
      icon: Zap,
      title: "Win Boosting",
      description: "Win specific matches to maintain your rank",
      features: ["Individual matches", "Flexible and fast", "Perfect for rank maintenance"],
    },
  ]

  return (
    <section id="services" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Our Services</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            We offer a wide range of boosting services to help you achieve your gaming goals
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 hover:transform hover:scale-105"
            >
              <CardHeader className="text-center">
                <div className="bg-purple-600/20 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <service.icon className="h-8 w-8 text-purple-400" />
                </div>
                <CardTitle className="text-white text-xl">{service.title}</CardTitle>
                <CardDescription className="text-gray-300">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-gray-300 text-sm flex items-center">
                      <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">View Pricing</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
