import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import Link from "next/link"

export function BoosterShowcase() {
  const boosters = [
    {
      name: "Guardian_Alex",
      avatar: "/placeholder.svg?height=200&width=200",
      role: "Raid Specialist",
      completedOrders: 2840,
      rating: 4.9,
      specialization: ["Day One Raids", "Sherpa Runs", "Master Raids"],
      available: true,
      achievements: ["World First Raider", "Sherpa God", "Flawless Master"],
    },
    {
      name: "TrialsKing_Sarah",
      avatar: "/placeholder.svg?height=200&width=200",
      role: "PvP Expert",
      completedOrders: 1560,
      rating: 5.0,
      specialization: ["Trials Flawless", "Competitive", "Private Matches"],
      available: true,
      achievements: ["Unbroken", "Flawless", "Legend"],
    },
    {
      name: "Nightfall_Mike",
      avatar: "/placeholder.svg?height=200&width=200",
      role: "PvE Specialist",
      completedOrders: 3200,
      rating: 4.8,
      specialization: ["GM Nightfalls", "Dungeons", "Solo Flawless"],
      available: false,
      achievements: ["Conqueror", "Solo Flawless", "Speedrunner"],
    },
    {
      name: "Seal_Hunter_Emma",
      avatar: "/placeholder.svg?height=200&width=200",
      role: "Title Specialist",
      completedOrders: 890,
      rating: 4.9,
      specialization: ["Seals & Titles", "Triumph Hunting", "Collections"],
      available: true,
      achievements: ["Chronicler", "Blacksmith", "Rivensbane"],
    },
  ]

  return (
    <section className="py-20 px-4 bg-[#0D1117]">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Meet Our Destiny 2 Experts</h2>
            <p className="text-gray-400 max-w-2xl">
              Our team consists of experienced Destiny 2 players with thousands of successful carries
            </p>
          </div>
          <Link href="/boosters">
            <Button variant="link" className="text-orange-400 hover:text-orange-300 p-0 h-auto flex items-center">
              View All Team Members <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {boosters.map((booster, index) => (
            <Card
              key={index}
              className="bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-orange-500/50 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="relative">
                    <Avatar className="h-24 w-24 border-2 border-orange-500">
                      <AvatarImage src={booster.avatar || "/placeholder.svg"} alt={booster.name} />
                      <AvatarFallback className="bg-orange-900 text-white text-xl">
                        {booster.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    {booster.available ? (
                      <div className="absolute bottom-1 right-1 h-4 w-4 rounded-full bg-green-500 border-2 border-gray-900"></div>
                    ) : (
                      <div className="absolute bottom-1 right-1 h-4 w-4 rounded-full bg-gray-500 border-2 border-gray-900"></div>
                    )}
                  </div>
                  <h3 className="text-xl font-bold text-white mt-4">{booster.name}</h3>
                  <p className="text-orange-400">{booster.role}</p>

                  <div className="flex items-center mt-2 mb-4">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className={`w-4 h-4 ${i < Math.floor(booster.rating) ? "text-yellow-400" : "text-gray-600"}`}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-white text-sm ml-1">{booster.rating}</span>
                  </div>

                  <div className="w-full space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Completed Orders:</span>
                      <span className="text-white font-medium">{booster.completedOrders}+</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Status:</span>
                      <span className={`font-medium ${booster.available ? "text-green-400" : "text-gray-400"}`}>
                        {booster.available ? "Available" : "Busy"}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-4 justify-center">
                    {booster.specialization.map((spec, i) => (
                      <Badge key={i} variant="outline" className="bg-gray-800/50 text-gray-300 border-gray-700 text-xs">
                        {spec}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-1 mt-3 justify-center">
                    {booster.achievements.map((achievement, i) => (
                      <Badge key={i} className="bg-orange-600/20 text-orange-400 hover:bg-orange-600/30 text-xs">
                        {achievement}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            Want to join our team? We're always looking for skilled Destiny 2 players to join our carry team.
          </p>
          <Button variant="outline" className="border-orange-500 text-orange-400 hover:bg-orange-500/10 bg-transparent">
            Apply as Booster
          </Button>
        </div>
      </div>
    </section>
  )
}
