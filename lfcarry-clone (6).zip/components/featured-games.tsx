import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

export function FeaturedGames() {
  const games = [
    {
      name: "League of Legends",
      image: "/placeholder.svg?height=300&width=500",
      logo: "/placeholder.svg?height=60&width=60",
      popular: true,
      services: ["Rank Boosting", "Coaching", "Duo Queue", "Placement Matches"],
      discount: "15% OFF",
    },
    {
      name: "Valorant",
      image: "/placeholder.svg?height=300&width=500",
      logo: "/placeholder.svg?height=60&width=60",
      popular: true,
      services: ["Rank Boosting", "Coaching", "Account Leveling"],
      discount: "10% OFF",
    },
    {
      name: "CS2",
      image: "/placeholder.svg?height=300&width=500",
      logo: "/placeholder.svg?height=60&width=60",
      popular: false,
      services: ["Rank Boosting", "Coaching", "Win Boosting"],
      discount: null,
    },
    {
      name: "Overwatch 2",
      image: "/placeholder.svg?height=300&width=500",
      logo: "/placeholder.svg?height=60&width=60",
      popular: false,
      services: ["Rank Boosting", "Coaching", "Placement Matches"],
      discount: null,
    },
  ]

  return (
    <section className="py-20 px-4 bg-[#0D1117]">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Featured Games</h2>
            <p className="text-gray-400 max-w-2xl">
              We offer professional boosting and coaching services for the most popular competitive games
            </p>
          </div>
          <Button variant="link" className="text-purple-400 hover:text-purple-300 p-0 h-auto flex items-center">
            View All Games <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {games.map((game, index) => (
            <Card
              key={index}
              className="bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-purple-500/50 transition-all duration-300 overflow-hidden group"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={game.image || "/placeholder.svg"}
                  alt={game.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {game.discount && (
                  <Badge className="absolute top-4 right-4 bg-purple-600 text-white font-medium">{game.discount}</Badge>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                <div className="absolute bottom-4 left-4 flex items-center">
                  <img
                    src={game.logo || "/placeholder.svg"}
                    alt={`${game.name} logo`}
                    className="w-10 h-10 rounded-full border-2 border-white/20"
                  />
                  <h3 className="text-xl font-bold text-white ml-3">{game.name}</h3>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="flex flex-wrap gap-2 mb-4">
                  {game.services.map((service, i) => (
                    <Badge key={i} variant="outline" className="bg-gray-800/50 text-gray-300 border-gray-700">
                      {service}
                    </Badge>
                  ))}
                </div>
                <Button className="w-full bg-gray-800 hover:bg-purple-600 text-white transition-colors">
                  View Services
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
