"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { MessageSquare, X, Send, Minimize2, Maximize2 } from "lucide-react"

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "support",
      text: "Hello! Welcome to D2Boost. How can I help you today?",
      time: "12:30 PM",
    },
  ])

  const toggleChat = () => {
    if (isMinimized) {
      setIsMinimized(false)
    } else {
      setIsOpen(!isOpen)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    const newMessage = {
      id: messages.length + 1,
      sender: "user",
      text: message,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, newMessage])
    setMessage("")

    // Simulate support response
    setTimeout(() => {
      const supportResponse = {
        id: messages.length + 2,
        sender: "support",
        text: "Thanks for your message! I'll help you with that right away.",
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }
      setMessages((prev) => [...prev, supportResponse])
    }, 1000)
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen && !isMinimized ? (
        <div className="bg-[#1A1F2E] border border-gray-700 rounded-lg shadow-xl w-80 md:w-96 flex flex-col transition-all duration-300 animate-in fade-in slide-in-from-bottom-5">
          <div className="flex items-center justify-between bg-gradient-to-r from-orange-600 to-red-600 p-4 rounded-t-lg">
            <div className="flex items-center">
              <Avatar className="h-8 w-8 mr-3">
                <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Support" />
                <AvatarFallback className="bg-orange-900 text-white">CS</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-white font-medium">Live Support</h3>
                <p className="text-orange-100 text-xs">Online • Avg response: 2 min</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20"
                onClick={() => setIsMinimized(true)}
              >
                <Minimize2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <div className="flex-1 p-4 overflow-y-auto max-h-80 space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "items-start"}`}>
                {msg.sender === "support" && (
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Support" />
                    <AvatarFallback className="bg-orange-900 text-white">CS</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`rounded-lg p-3 max-w-[80%] ${
                    msg.sender === "user"
                      ? "bg-gradient-to-r from-orange-600 to-red-600 text-white"
                      : "bg-gray-800 text-white"
                  }`}
                >
                  <p className="text-sm">{msg.text}</p>
                  <span className={`text-xs mt-1 block ${msg.sender === "user" ? "text-orange-100" : "text-gray-400"}`}>
                    {msg.time}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="border-t border-gray-700 p-3">
            <div className="flex items-center">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-gray-800 border-gray-600 text-white focus:border-orange-500 mr-2"
              />
              <Button
                type="submit"
                size="icon"
                className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                disabled={!message.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </div>
      ) : isMinimized ? (
        <div
          className="bg-[#1A1F2E] border border-gray-700 rounded-lg shadow-xl p-3 flex items-center justify-between cursor-pointer transition-all duration-300 animate-in fade-in slide-in-from-bottom-5"
          onClick={() => setIsMinimized(false)}
        >
          <div className="flex items-center">
            <Avatar className="h-8 w-8 mr-3">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Support" />
              <AvatarFallback className="bg-orange-900 text-white">CS</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-white font-medium">Live Support</h3>
              <p className="text-gray-400 text-xs">Click to expand</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white ml-2">
            <Maximize2 className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <Button
          onClick={toggleChat}
          className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white h-14 w-14 rounded-full shadow-lg flex items-center justify-center relative"
        >
          <MessageSquare className="h-6 w-6" />
          <div className="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-[#0F1419]"></div>
        </Button>
      )}
    </div>
  )
}
