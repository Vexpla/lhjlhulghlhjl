import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Target, Users, Zap, Gamepad, BookOpen } from "lucide-react"

export function PopularServices() {
  const boostingServices = [
    {
      icon: Trophy,
      title: "Rank Boosting",
      description: "Climb ranks quickly with our professional players",
      features: ["All ranks available", "Real-time progress tracking", "Secure account handling", "Guaranteed results"],
      price: "From $19.99",
      popular: true,
    },
    {
      icon: Target,
      title: "Placement Matches",
      description: "Get the best possible rank in your placement matches",
      features: ["10 guaranteed matches", "Optimized strategy", "Maximum rank possible", "Fast completion"],
      price: "From $29.99",
      popular: false,
    },
    {
      icon: Users,
      title: "Duo Queue",
      description: "Play alongside a professional and learn while you climb",
      features: ["Learn while playing", "Discord communication", "Personalized tips", "Flexible scheduling"],
      price: "From $24.99",
      popular: false,
    },
    {
      icon: Zap,
      title: "Win Boosting",
      description: "Win specific matches to maintain your rank",
      features: ["Individual matches", "Flexible and fast", "Perfect for rank maintenance", "High win rate"],
      price: "From $9.99",
      popular: false,
    },
  ]

  const coachingServices = [
    {
      icon: BookOpen,
      title: "Personal Coaching",
      description: "One-on-one sessions with a professional player",
      features: ["Personalized feedback", "Live coaching sessions", "Skill assessment", "Custom improvement plan"],
      price: "From $35.00/hr",
      popular: true,
    },
    {
      icon: Gamepad,
      title: "VOD Review",
      description: "Get your gameplay analyzed by a professional",
      features: ["Detailed analysis", "Mistake identification", "Improvement strategies", "Written feedback"],
      price: "From $25.00",
      popular: false,
    },
    {
      icon: Users,
      title: "Team Coaching",
      description: "Improve your team's coordination and strategy",
      features: ["Team dynamics", "Strategy development", "Role optimization", "Scrim analysis"],
      price: "From $60.00/hr",
      popular: false,
    },
    {
      icon: Trophy,
      title: "Champion Mastery",
      description: "Master specific champions or agents with expert guidance",
      features: ["Champion-specific tips", "Matchup knowledge", "Advanced techniques", "Build optimization"],
      price: "From $30.00/hr",
      popular: false,
    },
  ]

  return (
    <section className="py-20 px-4 bg-[#0D1117]">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Popular Services</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Choose from our wide range of professional boosting and coaching services
          </p>
        </div>

        <Tabs defaultValue="boosting" className="w-full">
          <div className="flex justify-center mb-8">
            <TabsList className="bg-gray-800/50">
              <TabsTrigger value="boosting" className="data-[state=active]:bg-purple-600 px-8">
                Boosting
              </TabsTrigger>
              <TabsTrigger value="coaching" className="data-[state=active]:bg-purple-600 px-8">
                Coaching
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="boosting" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {boostingServices.map((service, index) => (
                <Card
                  key={index}
                  className={`bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-purple-500/50 transition-all duration-300 ${
                    service.popular ? "border-purple-500/50 shadow-lg shadow-purple-500/10" : ""
                  }`}
                >
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start">
                      <div className="bg-purple-600/20 rounded-full p-3 w-12 h-12 flex items-center justify-center">
                        <service.icon className="h-6 w-6 text-purple-400" />
                      </div>
                      {service.popular && <Badge className="bg-purple-600 text-white">Most Popular</Badge>}
                    </div>
                    <CardTitle className="text-xl font-bold text-white mt-4">{service.title}</CardTitle>
                    <CardDescription className="text-gray-400">{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <ul className="space-y-2 mb-6">
                      {service.features.map((feature, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-center">
                          <div className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-gray-400">Starting at</span>
                      <span className="text-xl font-bold text-white">{service.price}</span>
                    </div>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">View Details</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="coaching" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {coachingServices.map((service, index) => (
                <Card
                  key={index}
                  className={`bg-gradient-to-b from-gray-900 to-gray-950 border-gray-800 hover:border-purple-500/50 transition-all duration-300 ${
                    service.popular ? "border-purple-500/50 shadow-lg shadow-purple-500/10" : ""
                  }`}
                >
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start">
                      <div className="bg-purple-600/20 rounded-full p-3 w-12 h-12 flex items-center justify-center">
                        <service.icon className="h-6 w-6 text-purple-400" />
                      </div>
                      {service.popular && <Badge className="bg-purple-600 text-white">Most Popular</Badge>}
                    </div>
                    <CardTitle className="text-xl font-bold text-white mt-4">{service.title}</CardTitle>
                    <CardDescription className="text-gray-400">{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <ul className="space-y-2 mb-6">
                      {service.features.map((feature, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-center">
                          <div className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-gray-400">Starting at</span>
                      <span className="text-xl font-bold text-white">{service.price}</span>
                    </div>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">View Details</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}
