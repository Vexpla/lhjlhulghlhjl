"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { CreditCard, Lock, Shield, CheckCircle, Mail } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { useAuth } from "@/hooks/use-auth"

export function CheckoutPage() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [orderComplete, setOrderComplete] = useState(false)
  const [orderData, setOrderData] = useState<any>(null)
  const { cartItems, getTotalPrice, clearCart } = useCart()
  const { user } = useAuth()

  const sendOrderEmail = async (orderDetails: any) => {
    // Simular envío de email
    console.log("Sending order confirmation email to:", orderDetails.email)
    console.log("Order details:", orderDetails)

    // En una aplicación real, aquí harías una llamada a tu API para enviar el email
    // Por ejemplo:
    // await fetch('/api/send-order-email', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(orderDetails)
    // })

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    const formData = new FormData(e.target as HTMLFormElement)
    const orderDetails = {
      orderId: `EC-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      customerName: formData.get("firstName") + " " + formData.get("lastName"),
      email: formData.get("email"),
      discordUsername: formData.get("discord"),
      platform: formData.get("platform"),
      bungieName: formData.get("bungieName"),
      items: cartItems,
      totalPrice: getTotalPrice(),
      orderDate: new Date().toISOString(),
      status: "pending",
    }

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 3000))

    // Send order confirmation email
    await sendOrderEmail(orderDetails)

    setOrderData(orderDetails)
    setIsProcessing(false)
    setOrderComplete(true)
    clearCart()
  }

  if (orderComplete && orderData) {
    return (
      <div className="pt-32 pb-16 px-4 bg-gray-900 min-h-screen">
        <div className="container mx-auto max-w-2xl">
          <Card className="bg-gray-800 border-gray-700 text-center">
            <CardContent className="p-12">
              <CheckCircle className="h-24 w-24 text-green-400 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">Order Confirmed!</h2>
              <p className="text-gray-300 mb-8">
                Thank you for your order! We'll start working on your services immediately. You'll receive updates via
                email and can track progress in your dashboard.
              </p>

              <div className="bg-gray-700/50 rounded-lg p-6 mb-8 text-left">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                  <Mail className="w-5 h-5 mr-2 text-blue-400" />
                  Order Details
                </h3>
                <div className="space-y-2 text-sm text-gray-300">
                  <div className="flex justify-between">
                    <span>Order ID:</span>
                    <span className="font-mono text-blue-400">{orderData.orderId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Customer:</span>
                    <span>{orderData.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Email:</span>
                    <span>{orderData.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Platform:</span>
                    <span>{orderData.platform}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total:</span>
                    <span className="font-bold text-blue-400">${orderData.totalPrice.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8">View Order Status</Button>
                <div className="text-sm text-gray-400">A confirmation email has been sent to {orderData.email}</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="pt-32 pb-16 px-4 bg-gray-900 min-h-screen">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-white flex items-center">
                  <Lock className="h-6 w-6 mr-2 text-green-400" />
                  Secure Checkout
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Contact Information</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-300">First Name</Label>
                        <Input
                          name="firstName"
                          required
                          className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                          defaultValue={user?.name?.split(" ")[0] || ""}
                        />
                      </div>
                      <div>
                        <Label className="text-gray-300">Last Name</Label>
                        <Input
                          name="lastName"
                          required
                          className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                          defaultValue={user?.name?.split(" ")[1] || ""}
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Email</Label>
                      <Input
                        name="email"
                        type="email"
                        required
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                        defaultValue={user?.email || ""}
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Discord Username</Label>
                      <Input
                        name="discord"
                        required
                        placeholder="username#1234"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Account Details</h3>
                    <div>
                      <Label className="text-gray-300">Destiny 2 Platform</Label>
                      <Select name="platform" required>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Select your platform" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="pc" className="text-white hover:bg-gray-600">
                            PC (Steam/Epic)
                          </SelectItem>
                          <SelectItem value="xbox" className="text-white hover:bg-gray-600">
                            Xbox
                          </SelectItem>
                          <SelectItem value="playstation" className="text-white hover:bg-gray-600">
                            PlayStation
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-300">Bungie Name</Label>
                      <Input
                        name="bungieName"
                        required
                        placeholder="Guardian#1234"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center">
                      <CreditCard className="h-5 w-5 mr-2" />
                      Payment Information
                    </h3>
                    <div>
                      <Label className="text-gray-300">Card Number</Label>
                      <Input
                        required
                        placeholder="1234 5678 9012 3456"
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-300">Expiry Date</Label>
                        <Input
                          required
                          placeholder="MM/YY"
                          className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                        />
                      </div>
                      <div>
                        <Label className="text-gray-300">CVV</Label>
                        <Input
                          required
                          placeholder="123"
                          className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Cardholder Name</Label>
                      <Input required className="bg-gray-700 border-gray-600 text-white placeholder-gray-400" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="terms" required />
                      <Label htmlFor="terms" className="text-gray-300 text-sm">
                        I agree to the{" "}
                        <a href="/terms" className="text-blue-400 hover:underline">
                          Terms of Service
                        </a>{" "}
                        and{" "}
                        <a href="/privacy" className="text-blue-400 hover:underline">
                          Privacy Policy
                        </a>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="updates" />
                      <Label htmlFor="updates" className="text-gray-300 text-sm">
                        Send me updates about my order and promotional offers
                      </Label>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-6 text-lg font-semibold"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Processing Payment...
                      </>
                    ) : (
                      <>
                        <Shield className="h-5 w-5 mr-2" />
                        Complete Order - ${getTotalPrice().toFixed(2)}
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="bg-gray-800 border-gray-700 sticky top-32">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-white">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between items-center">
                      <div>
                        <div className="text-white font-medium">{item.name}</div>
                        <div className="text-gray-400 text-sm">Qty: {item.quantity}</div>
                      </div>
                      <div className="text-blue-400 font-semibold">${(item.price * item.quantity).toFixed(2)}</div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-600 pt-4 space-y-2">
                  <div className="flex justify-between text-gray-400">
                    <span>Subtotal:</span>
                    <span>${getTotalPrice().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-400">
                    <span>Processing Fee:</span>
                    <span>$0.00</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-white">
                    <span>Total:</span>
                    <span className="text-blue-400">${getTotalPrice().toFixed(2)}</span>
                  </div>
                </div>

                <div className="bg-gray-700/50 rounded-lg p-4 space-y-2">
                  <div className="flex items-center text-green-400 text-sm">
                    <Shield className="h-4 w-4 mr-2" />
                    <span>SSL Encrypted & Secure</span>
                  </div>
                  <div className="flex items-center text-green-400 text-sm">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    <span>Money Back Guarantee</span>
                  </div>
                  <div className="flex items-center text-green-400 text-sm">
                    <Lock className="h-4 w-4 mr-2" />
                    <span>Account Safety Guaranteed</span>
                  </div>
                  <div className="flex items-center text-blue-400 text-sm">
                    <Mail className="h-4 w-4 mr-2" />
                    <span>Email confirmation sent</span>
                  </div>
                </div>

                <div className="text-center text-sm text-gray-400">
                  Your order will begin within 1-2 hours of payment confirmation
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
