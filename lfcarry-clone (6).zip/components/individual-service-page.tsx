"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, CheckCircle, ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"
import { useCart } from "@/hooks/use-cart"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

// Datos completos de servicios individuales
const individualServicesData = {
  "last-wish": {
    title: "Last Wish Raid",
    description: "Complete the Last Wish raid and get 1000 Voices exotic",
    basePrice: 29,
    image: "/placeholder.svg?height=400&width=600&text=Last+Wish+Raid",
    rating: 4.9,
    completionTime: "1-2 hours",
    category: "Raids",
    difficulty: "High",
    features: ["1000 Voices Chance", "All Raid Loot", "Experienced Team", "Fast Completion"],
    options: [
      { id: "1000-voices", name: "1000 Voices Guaranteed", price: 45 },
      { id: "stream", name: "Stream Service", price: 5 },
      { id: "express", name: "Express (Priority)", price: 15 },
      { id: "sherpa", name: "Sherpa Mode (Learn)", price: 10 },
    ],
    whatYouGet: [
      "Complete Last Wish raid",
      "All items and resources that drop",
      "Experience for Season Pass and Artifact",
      "Raid completion triumph",
      "Chance at 1000 Voices exotic",
    ],
  },
  "garden-salvation": {
    title: "Garden of Salvation",
    description: "Complete Garden of Salvation and get Divinity exotic",
    basePrice: 35,
    image: "/placeholder.svg?height=400&width=600&text=Garden+Salvation",
    rating: 4.8,
    completionTime: "2-3 hours",
    category: "Raids",
    difficulty: "Very High",
    features: ["Divinity Quest", "All Raid Loot", "Puzzle Solutions", "Professional Team"],
    options: [
      { id: "divinity", name: "Divinity Guaranteed", price: 25 },
      { id: "stream", name: "Stream Service", price: 5 },
      { id: "sherpa", name: "Sherpa Mode (Learn)", price: 10 },
      { id: "catalyst", name: "Divinity Catalyst", price: 20 },
    ],
    whatYouGet: [
      "Complete Garden of Salvation raid",
      "All raid weapons and armor",
      "Divinity exotic trace rifle (if selected)",
      "All puzzle solutions completed",
      "Raid completion triumph",
    ],
  },
  "deep-stone-crypt": {
    title: "Deep Stone Crypt",
    description: "Complete Deep Stone Crypt and get Eyes of Tomorrow",
    basePrice: 32,
    image: "/placeholder.svg?height=400&width=600&text=Deep+Stone+Crypt",
    rating: 4.9,
    completionTime: "1.5-2 hours",
    category: "Raids",
    difficulty: "High",
    features: ["Eyes of Tomorrow", "Raid Weapons", "Armor Sets", "Fast Clear"],
    options: [
      { id: "eyes-tomorrow", name: "Eyes of Tomorrow", price: 40 },
      { id: "stream", name: "Stream Service", price: 5 },
      { id: "flawless", name: "Flawless Run", price: 89 },
      { id: "sherpa", name: "Sherpa Mode", price: 10 },
    ],
    whatYouGet: [
      "Complete Deep Stone Crypt raid",
      "All raid weapons and armor",
      "Eyes of Tomorrow exotic rocket launcher (if selected)",
      "Raid completion triumph",
      "Experience and materials",
    ],
  },
  duality: {
    title: "Duality Dungeon",
    description: "Complete Duality dungeon and get exclusive rewards",
    basePrice: 19,
    image: "/placeholder.svg?height=400&width=600&text=Duality+Dungeon",
    rating: 4.9,
    completionTime: "45-90 min",
    category: "Dungeons",
    difficulty: "Medium",
    features: ["Heartshadow Exotic", "Dungeon Loot", "Triumph Progress", "Fast Completion"],
    options: [
      { id: "heartshadow", name: "Heartshadow Exotic", price: 35 },
      { id: "stream", name: "Stream Service", price: 5 },
      { id: "master", name: "Master Difficulty", price: 25 },
      { id: "solo-flawless", name: "Solo Flawless", price: 89 },
    ],
    whatYouGet: [
      "Complete Duality dungeon",
      "All dungeon weapons and armor",
      "Heartshadow exotic sword (if selected)",
      "Dungeon completion triumph",
      "Masterwork materials",
    ],
  },
  "flawless-carry": {
    title: "Trials Flawless (7-0)",
    description: "Get carried to flawless victory and lighthouse access",
    basePrice: 79,
    image: "/placeholder.svg?height=400&width=600&text=Trials+Flawless",
    rating: 4.8,
    completionTime: "2-6 hours",
    category: "PvP",
    difficulty: "Very High",
    features: ["Flawless Guaranteed", "Adept Weapons", "Lighthouse Access", "Professional Players"],
    options: [
      { id: "adept-weapons", name: "Specific Adept Weapon", price: 25 },
      { id: "stream", name: "Stream Service", price: 10 },
      { id: "express", name: "Express Service", price: 40 },
      { id: "coaching", name: "Coaching During Carry", price: 30 },
    ],
    whatYouGet: [
      "Flawless Trials passage (7-0)",
      "Access to the Lighthouse",
      "Adept weapons from chest",
      "Trials armor and weapons",
      "Flawless triumph completion",
    ],
  },
  "whirling-ovation": {
    title: "Whirling Ovation Exotic Rocket Launcher",
    description: "Get the Whirling Ovation exotic rocket launcher",
    basePrice: 89,
    image: "/placeholder.svg?height=400&width=600&text=Whirling+Ovation",
    rating: 4.9,
    completionTime: "3-5 hours",
    category: "Exotic Quests",
    difficulty: "High",
    features: ["Exotic Rocket Launcher", "Catalyst Available", "All Quest Steps", "Masterwork Option"],
    options: [
      { id: "catalyst", name: "Obtain the Catalyst", price: 89 },
      { id: "masterwork", name: "Masterwork the Catalyst", price: 15 },
      { id: "stream", name: "Stream Service", price: 5 },
      { id: "express", name: "Express Service", price: 45 },
    ],
    whatYouGet: [
      "Whirling Ovation exotic rocket launcher",
      "All quest steps completed",
      "Catalyst (if selected)",
      "Masterwork materials",
      "Experience and progress",
    ],
  },
  "single-gm": {
    title: "Single GM Nightfall",
    description: "Complete one Grandmaster Nightfall",
    basePrice: 24,
    image: "/placeholder.svg?height=400&width=600&text=GM+Nightfall",
    rating: 4.8,
    completionTime: "30-60 min",
    category: "GM Nightfalls",
    difficulty: "Very High",
    features: ["Adept Weapons", "Ascendant Shards", "Platinum Rewards", "Safe Completion"],
    options: [
      { id: "adept-weapon", name: "Specific Adept Weapon", price: 15 },
      { id: "stream", name: "Stream Service", price: 5 },
      { id: "platinum", name: "Platinum Rewards", price: 10 },
      { id: "multiple", name: "Multiple Runs (3x)", price: 35 },
    ],
    whatYouGet: [
      "Grandmaster Nightfall completion",
      "Adept weapons",
      "Ascendant Shards",
      "Enhancement Prisms",
      "Platinum score rewards",
    ],
  },
  "soft-cap": {
    title: "Soft Cap Leveling (1800)",
    description: "Level up to the soft cap quickly",
    basePrice: 39,
    image: "/placeholder.svg?height=400&width=600&text=Soft+Cap+Leveling",
    rating: 4.7,
    completionTime: "1-2 days",
    category: "Power Leveling",
    difficulty: "Low",
    features: ["Fast Leveling", "Efficient Routes", "All Activities", "Gear Optimization"],
    options: [
      { id: "express", name: "Express Service", price: 20 },
      { id: "stream", name: "Stream Service", price: 10 },
      { id: "specific-gear", name: "Specific Gear Focus", price: 15 },
      { id: "materials", name: "Extra Materials", price: 12 },
    ],
    whatYouGet: [
      "Power level 1800 (soft cap)",
      "Optimized gear loadout",
      "All activities completed efficiently",
      "Materials and resources",
      "Season pass progress",
    ],
  },
}

interface IndividualServicePageProps {
  serviceId: string
}

export function IndividualServicePage({ serviceId }: IndividualServicePageProps) {
  const [selectedOptions, setSelectedOptions] = useState<string[]>([])
  const [customRequest, setCustomRequest] = useState("")
  const [platform, setPlatform] = useState("")
  const { addItem } = useCart()

  const serviceData = individualServicesData[serviceId as keyof typeof individualServicesData]

  if (!serviceData) {
    return (
      <div className="min-h-screen bg-gray-900">
        <Header />
        <main className="py-12">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold text-white mb-4">Service Not Found</h1>
            <Link href="/services">
              <Button className="bg-blue-600 hover:bg-blue-700">Back to Services</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const calculateTotalPrice = () => {
    let total = serviceData.basePrice
    selectedOptions.forEach((optionId) => {
      const option = serviceData.options.find((opt) => opt.id === optionId)
      if (option) total += option.price
    })
    return total
  }

  const handleAddToCart = () => {
    const optionsText =
      selectedOptions.length > 0
        ? ` + ${selectedOptions.map((optId) => serviceData.options.find((opt) => opt.id === optId)?.name).join(", ")}`
        : ""

    addItem({
      id: `${serviceId}-${Date.now()}`,
      name: `${serviceData.title}${optionsText}`,
      price: calculateTotalPrice(),
      quantity: 1,
      image: serviceData.image,
    })
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />

      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          {/* Breadcrumb */}
          <div className="mb-8">
            <Link href="/services" className="flex items-center text-blue-400 hover:text-blue-300 mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Services
            </Link>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Service Details */}
            <div className="lg:col-span-2 space-y-6">
              {/* Header */}
              <div className="text-center mb-8">
                <img
                  src={serviceData.image || "/placeholder.svg"}
                  alt={serviceData.title}
                  className="w-full h-64 object-cover rounded-lg mb-6"
                />
                <h1 className="text-4xl font-bold text-white mb-4">{serviceData.title}</h1>
                <p className="text-xl text-gray-300">{serviceData.description}</p>
                <div className="flex items-center justify-center space-x-4 mt-4">
                  <div className="flex items-center space-x-1">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="text-white font-medium">{serviceData.rating}</span>
                  </div>
                  <Badge className="bg-blue-600 text-white">{serviceData.category}</Badge>
                  <Badge
                    className={`${
                      serviceData.difficulty === "Low"
                        ? "bg-green-600"
                        : serviceData.difficulty === "Medium"
                          ? "bg-yellow-600"
                          : serviceData.difficulty === "High"
                            ? "bg-orange-600"
                            : "bg-red-600"
                    } text-white`}
                  >
                    {serviceData.difficulty}
                  </Badge>
                </div>
              </div>

              {/* Trust Badge */}
              <div className="bg-green-900/30 border border-green-700 rounded-lg p-4 text-center mb-8">
                <div className="flex items-center justify-center space-x-4">
                  <span className="text-green-300 font-medium">Trusted by thousands</span>
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-green-400 text-green-400" />
                    ))}
                  </div>
                  <span className="text-green-300">Over 10,300 reviews</span>
                </div>
              </div>

              {/* Options */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Recommended Options</CardTitle>
                  <CardDescription className="text-gray-400">
                    Enhance your service with additional options
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {serviceData.options.map((option) => (
                    <div
                      key={option.id}
                      className="flex items-center justify-between p-3 border border-gray-600 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id={option.id}
                          checked={selectedOptions.includes(option.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedOptions([...selectedOptions, option.id])
                            } else {
                              setSelectedOptions(selectedOptions.filter((id) => id !== option.id))
                            }
                          }}
                        />
                        <label htmlFor={option.id} className="text-white font-medium cursor-pointer">
                          {option.name}
                        </label>
                      </div>
                      <div className="text-blue-400 font-semibold">+${option.price}</div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Custom Request */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Custom Request</CardTitle>
                  <CardDescription className="text-gray-400">
                    Write your request here to customize: ETAs, Schedule, RNG, Progress discounts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder="Describe any specific requirements or preferences..."
                    value={customRequest}
                    onChange={(e) => setCustomRequest(e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                    rows={4}
                  />
                </CardContent>
              </Card>

              {/* Platform Selection */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Platform</CardTitle>
                  <CardDescription className="text-gray-400">Select your gaming platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Select your platform" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      <SelectItem value="pc" className="text-white hover:bg-gray-600">
                        PC (Steam/Epic)
                      </SelectItem>
                      <SelectItem value="xbox" className="text-white hover:bg-gray-600">
                        Xbox
                      </SelectItem>
                      <SelectItem value="playstation" className="text-white hover:bg-gray-600">
                        PlayStation
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="bg-gray-800 border-gray-700 sticky top-24">
                <CardHeader>
                  <CardTitle className="text-white">What you get</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    {serviceData.whatYouGet.map((item, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                        <span className="text-white">{item}</span>
                      </div>
                    ))}
                    {selectedOptions.map((optionId) => {
                      const option = serviceData.options.find((opt) => opt.id === optionId)
                      return option ? (
                        <div key={optionId} className="flex items-center space-x-2">
                          <Plus className="w-5 h-5 text-blue-400 flex-shrink-0" />
                          <span className="text-white">{option.name}</span>
                        </div>
                      ) : null
                    })}
                  </div>

                  <div className="border-t border-gray-600 pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-gray-400">Estimated time:</span>
                      <span className="text-white">{serviceData.completionTime}</span>
                    </div>
                    <div className="flex justify-between items-center text-2xl font-bold">
                      <span className="text-white">Total:</span>
                      <span className="text-blue-400">${calculateTotalPrice()}</span>
                    </div>
                  </div>

                  <Button
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg font-semibold"
                    onClick={handleAddToCart}
                    disabled={!platform}
                  >
                    Add to Cart
                  </Button>

                  <div className="text-center text-sm text-gray-400">Select platform to continue</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
