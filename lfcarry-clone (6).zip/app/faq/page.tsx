import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FAQ } from "@/components/faq"

export default function FAQPage() {
  return (
    <div className="min-h-screen bg-[#0F1419]">
      <Header />
      <div className="pt-32 pb-16">
        <FAQ />
      </div>
      <Footer />
    </div>
  )
}
