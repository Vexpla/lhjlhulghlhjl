import { ServiceDetailPage } from "@/components/service-detail-page"

interface ServicePageProps {
  params: {
    serviceId: string
  }
}

export default function ServicePage({ params }: ServicePageProps) {
  return <ServiceDetailPage serviceId={params.serviceId} />
}
