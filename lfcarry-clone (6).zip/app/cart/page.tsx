import { CartPage } from "@/components/cart-page"

export default function Cart() {
  return <CartPage />
}
