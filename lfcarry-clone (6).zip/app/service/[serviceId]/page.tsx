import { IndividualServicePage } from "@/components/individual-service-page"

interface ServicePageProps {
  params: {
    serviceId: string
  }
}

export default function ServicePage({ params }: ServicePageProps) {
  return <IndividualServicePage serviceId={params.serviceId} />
}
