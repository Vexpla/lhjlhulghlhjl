import { RegisterPage } from "@/components/register-page"

export default function Register() {
  return <RegisterPage />
}
