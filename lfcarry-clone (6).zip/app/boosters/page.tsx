import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BoostersPage } from "@/components/boosters-page"

export default function Boosters() {
  return (
    <div className="min-h-screen bg-[#0B0E14]">
      <Header />
      <BoostersPage />
      <Footer />
    </div>
  )
}
