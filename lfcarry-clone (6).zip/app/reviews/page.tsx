import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ReviewsPage } from "@/components/reviews-page"

export default function Reviews() {
  return (
    <div className="min-h-screen bg-[#0F1419]">
      <Header />
      <ReviewsPage />
      <Footer />
    </div>
  )
}
